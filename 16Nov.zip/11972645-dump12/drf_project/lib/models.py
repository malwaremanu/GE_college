from django.db import models


class Publisher(models.Model):
    name= models.CharField(max_length=100)
    address = models.TextField(blank=True)
    phone = models.CharField(max_length=10, blank=True)
    email = models.CharField(max_length=50, blank=True)
    website = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return self.name


class Vendor(models.Model):
    name= models.CharField(max_length=50)
    address = models.TextField()
    phone = models.CharField(max_length=10)
    email = models.CharField(max_length=50)

    def __str__(self):
        return self.name

# Create your models here.
class Catalog(models.Model):
    name=models.TextField()
    date =models.TextField()
    uuid = models.TextField()
    acc_no = models.TextField()
    photo = models.TextField()
    author = models.TextField()
    title = models.TextField()
    desc = models.TextField()
    edition = models.TextField()
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE)
    place = models.TextField()
    year = models.TextField()
    pages = models.TextField()
    class_no = models.TextField()
    bound = models.TextField()
    source = models.TextField()
    mrp = models.TextField()
    net = models.TextField()
    size_cm = models.TextField()
    remark = models.TextField()
    shelf = models.TextField()
    is_issued = models.TextField()
    category = models.TextField()
    sub_category = models.TextField()

    def __str__(self):
        return self.name