from rest_framework import serializers
from .models import Publisher

class GetPublisher(serializers.ModelSerializer):
    class Meta:
        model = Publisher
        fields = ('name',)

        def create(self,validated_data):
            return Publisher.objects.create(**validated_data)
