from rest_framework import serializers
# from .models import GetStatesList,Bank,Exams,Categories,Specialisation,Transaction,User,Officers,BankWindow
from .models import Bank

class GetBanksListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bank
        fields = ('name',)

        def create(self,validated_data):
            return Bank.objects.create(**validated_data)

        def update(self,instance,validated_data):
            instance.name=validated_data.get("name",instance.name)
            # instance.code=validated_data.get("code",instance.code)
            # instance.from_date=validated_data.get("from_date",instance.from_date)
            # instance.to_date=validated_data.get("to_date",instance.to_date)
            # instance.exam_code=validated_data.get("exam_code",instance.exam_code)
            instance.save()
            return instance

"""
{
    "name" : "testname",
    "code" : 2345,
    "exam_code" : 'examcode',
}


"""