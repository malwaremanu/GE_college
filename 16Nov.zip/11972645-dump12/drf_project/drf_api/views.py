from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
# Create your views here.
from .serializers import GetBanksListSerializer
from .models import Bank
from rest_framework.decorators import api_view
# authentication_classes,permission_classes

# from rest_framework_simplejwt.authentication import JWTTokenUserAuthentication
from rest_framework.permissions import IsAuthenticated,AllowAny
from rest_framework.response import Response

@api_view(['GET','POST', 'DELETE'])
# @authentication_classes([JWTTokenUserAuthentication])
# @permission_classes([AllowAny])
def getBanksList(request):
    if request.method == 'GET':
        banks=Bank.objects.all().order_by('name')
        serializer=GetBanksListSerializer(banks,many=True)
        return Response(serializer.data)
    
    if request.method =='POST':
        print(request.data)
        serializer=GetBanksListSerializer(many=True,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)
    
    if request.method == 'DELETE':
        name = request.data["name"]
        bank=Bank.objects.get(name=name)
        bank.delete()
        return Response("deleted")

def index(request):
    return JsonResponse({
        "msg": "welcome to apis"
    })
