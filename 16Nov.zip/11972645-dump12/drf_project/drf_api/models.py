from django.db import models

# Create your models here.
from datetime import timezone
from django.db import models


class User(models.Model):
    username=models.TextField()
    password=models.TextField()
    bank_code=models.IntegerField()

class Bank(models.Model):
    name=models.TextField()
    # code=models.IntegerField(primary_key=True)
    # #exam_code=models.ForeignKey(Exams,on_delete=CASCADE,null=True,blank=True)
    # from_date=models.TextField(default="2021-01-01")
    # to_date=models.TextField(default="2021-12-01")

    def __str__(self):
        return self.code