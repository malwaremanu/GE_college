from django.contrib import admin
from django.urls import path, include
from . import views


# from vacancy_filling.bankView import getBanksList

urlpatterns = [
    path('', views.index, name="main_api_index"),
    path('getBanksList/', views.getBanksList,name="banks-list"),
]
