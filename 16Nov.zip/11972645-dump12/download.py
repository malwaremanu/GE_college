import os, requests

os.system("clear")

list_of_books = os.listdir("data")
print(list_of_books)


for book in list_of_books
#"wget -O latest-hugo.zip https://github.com/gohugoio/hugo/archive/master.zip"