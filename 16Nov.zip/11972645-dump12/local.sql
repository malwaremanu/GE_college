-- MySQL dump 10.13  Distrib 8.0.27, for macos11.6 (arm64)
--
-- Host: localhost    Database: gungunerp_local
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add user',7,'add_user'),(26,'Can change user',7,'change_user'),(27,'Can delete user',7,'delete_user'),(28,'Can view user',7,'view_user'),(29,'Can add config',8,'add_config'),(30,'Can change config',8,'change_config'),(31,'Can delete config',8,'delete_config'),(32,'Can view config',8,'view_config'),(33,'Can add courses',9,'add_courses'),(34,'Can change courses',9,'change_courses'),(35,'Can delete courses',9,'delete_courses'),(36,'Can view courses',9,'view_courses'),(37,'Can add classes',10,'add_classes'),(38,'Can change classes',10,'change_classes'),(39,'Can delete classes',10,'delete_classes'),(40,'Can view classes',10,'view_classes'),(41,'Can add roles',11,'add_roles'),(42,'Can change roles',11,'change_roles'),(43,'Can delete roles',11,'delete_roles'),(44,'Can view roles',11,'view_roles');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$260000$yL6UEpRy5V20mFE0B7ZHnP$2fXu1jBfPRczP5vmgXzN2a8nOQc5JlejyuBnDpEFRMk=','2021-11-11 14:50:37.012226',1,'super','','','super@gmail.com',1,1,'2021-11-09 17:47:29.036070');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2021-11-09 17:48:22.623413','1','',1,'[{\"added\": {}}]',7,1),(2,'2021-11-10 19:22:42.682922','e50bc7f4-f500-486c-9bfc-300442f1b85e','config object (e50bc7f4-f500-486c-9bfc-300442f1b85e)',1,'[{\"added\": {}}]',8,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(10,'masters','classes'),(8,'masters','config'),(9,'masters','courses'),(11,'masters','roles'),(6,'sessions','session'),(7,'users','user');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2021-11-09 17:46:01.354182'),(2,'auth','0001_initial','2021-11-09 17:46:10.157783'),(3,'admin','0001_initial','2021-11-09 17:46:14.707824'),(4,'admin','0002_logentry_remove_auto_add','2021-11-09 17:46:15.321179'),(5,'admin','0003_logentry_add_action_flag_choices','2021-11-09 17:46:15.624600'),(6,'contenttypes','0002_remove_content_type_name','2021-11-09 17:46:16.684361'),(7,'auth','0002_alter_permission_name_max_length','2021-11-09 17:46:17.152349'),(8,'auth','0003_alter_user_email_max_length','2021-11-09 17:46:17.601346'),(9,'auth','0004_alter_user_username_opts','2021-11-09 17:46:17.905842'),(10,'auth','0005_alter_user_last_login_null','2021-11-09 17:46:18.377732'),(11,'auth','0006_require_contenttypes_0002','2021-11-09 17:46:18.663265'),(12,'auth','0007_alter_validators_add_error_messages','2021-11-09 17:46:18.955260'),(13,'auth','0008_alter_user_username_max_length','2021-11-09 17:46:19.407217'),(14,'auth','0009_alter_user_last_name_max_length','2021-11-09 17:46:19.868431'),(15,'auth','0010_alter_group_name_max_length','2021-11-09 17:46:20.325949'),(16,'auth','0011_update_proxy_permissions','2021-11-09 17:46:21.054651'),(17,'auth','0012_alter_user_first_name_max_length','2021-11-09 17:46:21.514725'),(18,'sessions','0001_initial','2021-11-09 17:46:22.836380'),(19,'users','0001_initial','2021-11-09 17:46:26.716092'),(20,'masters','0001_initial','2021-11-09 18:18:06.961874');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0dnxpmtym5lubcrt68dqbqgcjq2cj2iy','.eJxVT0sOwiAQvQvrhkBpCxpj_MWdZ2hmCli0tKbQlfHuQtKF7t7M-8y8N2lhiX27BDO3TpMt4aT43SF0TzNmQj9gvE-0m8Y4O6RZQlc20NukzXBatX8BPYQ-ucuuUY1F5EIJy4QpldIcoJYblKayNVMNMBQVYww5F1bW0m66BlSlSqk1ptAcN4I3Ke14Ol9260Maqc_XA7XODOmX4xKna4b7ZIouDtkRwL8SKIjx4Aaei5bicM9DquTJ5wtPp1ax:1mlC9g:B4aUlZxswn4qYQSnwGx4jQ-Z9yzuDKcZQRpzdBg9N9Y','2021-11-25 15:38:24.791254'),('3aaud0emuy8op4gdrt6ankhxxe2k18rb','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mlCH4:f0vU_ZTyZoq5_A-ZhaWk7hhyTje1FK7P1CyVv3G_SOk','2021-11-25 15:46:02.859255'),('7alqwm8dc6hlfnb51ashp4qpng0ks0vy','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkrBs:WGv50BIGRfYbjY1-_I095SqI8rGgtXhMaYfyFJey5nM','2021-11-24 17:15:16.932535'),('7xcyxj060ikd08f3ijiduw06sw7o7s1i','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mlAZJ:KQNIcJ2CZTQ_kP0A4BEwgTchyci5xjWD3-U1tNWYTl4','2021-11-25 13:56:45.144070'),('8mgiaufd1j6qyav0dyr57p666nj4eii9','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkrPC:2E2El9oRpWz-sAtWV6jyisXIaf-EaWq5kwxd4uovC2k','2021-11-24 17:29:02.198744'),('c32bfohyab1bsnpcjcpzmhvkiyjhp8c5','.eJxVjEsKwjAUAO-StYTm5WPi0r1nCO-T2Kq00LQr8e4S6EK3M8O8VcZ9G_PeyponURdl1OmXEfKzzF3IA-f7onmZt3Ui3RN92KZvi5TX9Wj_BiO2sW9TiexNcAn9kJhJBIKL3grh4Ax7BrQAtVY8swBQccYmomAtcElRfb7m2Tgk:1mkVDi:AQJhoKkRW3Ms_wAZvXr41FadOVZFGMkpSxdXv7yPu-k','2021-11-23 17:47:42.017832'),('gwdvti77gxnirjrwf9q423gebb6fsa48','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkVbT:2AjXdRGFsFut0JrklUN3LH0niGu_nwhLT2M3Z4CgOC4','2021-11-23 18:12:15.104571'),('nl0y0o5uraurdn96yeqav9zbgq9m3qg2','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mlCSX:D0c2jkDFw01NBAxAcMeEthWyylDRq_1If_fnbpetyPg','2021-11-25 15:57:53.147600'),('rvtsmehli0vfvlcsul3apvmu39idcb0d','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkrPE:HNqajUQbrKNhdr4WFfWXL2JRj0SJWPwzj8d6CINcOZE','2021-11-24 17:29:04.147863'),('xxz6fi6z1p0hwej6tch067yc6qehidef','.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mlAcW:peMl-sualBBBuVFqBaS2Yd-mkIQHl4Cd5Wv5bACga8Y','2021-11-25 14:00:04.517563');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masters_classes`
--

DROP TABLE IF EXISTS `masters_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `masters_classes` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_classes_created_by_id_9a91a133_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_classes_created_by_id_9a91a133_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masters_classes`
--

LOCK TABLES `masters_classes` WRITE;
/*!40000 ALTER TABLE `masters_classes` DISABLE KEYS */;
INSERT INTO `masters_classes` VALUES ('1de8b21525a543738b99481bde1b1278','Sample Class Name 2',1,1),('77340f85b8684270a0dd547f54f82d81','Sample Class Name 1',1,1),('8fda7bd4f9684b40805ae4a0ebf07159','Sample Class Name 3',1,1);
/*!40000 ALTER TABLE `masters_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masters_config`
--

DROP TABLE IF EXISTS `masters_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `masters_config` (
  `id` char(32) NOT NULL,
  `contact_number_1` longtext NOT NULL,
  `contact_number_2` longtext NOT NULL,
  `college_name` longtext NOT NULL,
  `college_short_name` varchar(4) NOT NULL,
  `address` longtext NOT NULL,
  `affi_reg_number` longtext NOT NULL,
  `sign_auth` longtext NOT NULL,
  `logo` varchar(100) NOT NULL,
  `background_image` varchar(100) NOT NULL,
  `board_logo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masters_config`
--

LOCK TABLES `masters_config` WRITE;
/*!40000 ALTER TABLE `masters_config` DISABLE KEYS */;
INSERT INTO `masters_config` VALUES ('e50bc7f4f500486c9bfc300442f1b85e','98555555','5545455','abc college','abc','adhhj','','','uploads/Gautam_Buddha.png','uploads/bldmg.jpg','uploads/rama_logo.png');
/*!40000 ALTER TABLE `masters_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masters_courses`
--

DROP TABLE IF EXISTS `masters_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `masters_courses` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `duration` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_courses_created_by_id_c9901862_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_courses_created_by_id_c9901862_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masters_courses`
--

LOCK TABLES `masters_courses` WRITE;
/*!40000 ALTER TABLE `masters_courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `masters_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masters_roles`
--

DROP TABLE IF EXISTS `masters_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `masters_roles` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_roles_created_by_id_5903cb90_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_roles_created_by_id_5903cb90_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masters_roles`
--

LOCK TABLES `masters_roles` WRITE;
/*!40000 ALTER TABLE `masters_roles` DISABLE KEYS */;
INSERT INTO `masters_roles` VALUES ('aeebdafa9b4e4ae4ae040f9790210ede','Manager Post',1,1),('d72d60eecd604e159a6c76ead8473b10','Accountant',1,1);
/*!40000 ALTER TABLE `masters_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_user`
--

DROP TABLE IF EXISTS `users_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(32) NOT NULL,
  `password` varchar(1024) NOT NULL,
  `dob` date NOT NULL,
  `title` longtext NOT NULL,
  `email1` longtext NOT NULL,
  `marital_status` longtext NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` longtext NOT NULL,
  `scope` longtext NOT NULL,
  `post` longtext NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_user`
--

LOCK TABLES `users_user` WRITE;
/*!40000 ALTER TABLE `users_user` DISABLE KEYS */;
INSERT INTO `users_user` VALUES (1,'d07e0c06095f419e9ee274f74b37959c','123','1970-12-01','sample','123@gmail.com','','9024343890','','','');
/*!40000 ALTER TABLE `users_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-12  8:42:18
