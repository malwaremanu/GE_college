function NewMeetups(){

    return (
        <div>
            New meetup Page
        </div>
    )
}

export default NewMeetups;