function AllMeetings(){
    console.log("all meetups page.")

    return (
        <div>
            All Meetings Page
        </div>
    )
}

export default AllMeetings;