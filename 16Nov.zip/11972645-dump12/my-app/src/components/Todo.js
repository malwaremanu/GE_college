import {useState} from 'react';
import Modal from './Modal';

function Todo(props){

    const [modalIsOpen, SetModalIsOpen] = useState(false);


    function deleted(){
        console.log(props.text)
        SetModalIsOpen(true);

    }

    function closeModal(){
        console.log("we will close it.")
        SetModalIsOpen(false);
    }

    return (
        <div className="p-3 bg-green-200 flex items-center justify-between mb-1">
            <h1>
               {props.text}
            </h1>
            <button onClick={deleted} className="bg-green-500 px-4 py-2 text-white rounded hover:shadow-xl hover:green-600">
                {props.ph}
            </button>
            {modalIsOpen && <Modal text={props.text} ph={props.ph} onClose={closeModal} onConfirm={closeModal} />}
        </div>
    )
}

export default Todo;