function MainNavigation() {
  return (
    <header>
      <div className="bg-gray-900 p-3 text-white font-semibold flex-none">
        Some Header
      </div>
    </header>
  );
}

export default MainNavigation;
