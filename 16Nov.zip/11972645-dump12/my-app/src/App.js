// import Todo from "./components/Todo";
import { Route, Switch } from "react-router-dom";
import NewMeetups from "./pages/NewMeetups";
import AllMeetings from "./pages/AllMeetings";
import MainNavigation from './components/layout/MainNavigation';

function App() {
  return (
    <div className="flex flex-col">
      <MainNavigation />
      <div className="flex-grow">Hello again</div>

      <Switch>
        <Route path="/" exact={true}>
          <NewMeetups />
        </Route>

        <Route path="/all">
          <AllMeetings />
        </Route>
      </Switch>

      <div className="bg-gray-900 p-3 text-white  font-semibold flex-none z-10 fixed bottom-0 w-full mt-4">
        Some Footer
      </div>
    </div>
  );
}

export default App;
