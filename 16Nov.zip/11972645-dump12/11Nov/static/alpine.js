(() => {
    var Fe = !1,
        je = !1,
        J = [];

    function wt(e) {
        Kr(e)
    }

    function Kr(e) {
        J.includes(e) || J.push(e), zr()
    }

    function zr() {
        !je && !Fe && (Fe = !0, queueMicrotask(Vr))
    }

    function Vr() {
        Fe = !1, je = !0;
        for (let e = 0; e < J.length; e++) J[e]();
        J.length = 0, je = !1
    }
    var v, C, V, Ke, ze = !0;

    function Et(e) {
        ze = !1, e(), ze = !0
    }

    function St(e) {
        v = e.reactive, V = e.release, C = t => e.effect(t, {
            scheduler: r => {
                ze ? wt(r) : r()
            }
        }), Ke = e.raw
    }

    function Ve(e) {
        C = e
    }

    function At(e) {
        let t = () => {};
        return [n => {
            let i = C(n);
            e._x_effects || (e._x_effects = new Set, e._x_runEffects = () => {
                e._x_effects.forEach(o => o())
            }), e._x_effects.add(i), t = () => {
                i !== void 0 && (e._x_effects.delete(i), V(i))
            }
        }, () => {
            t()
        }]
    }
    var Ot = [],
        Tt = [],
        Rt = [];

    function Ct(e) {
        Rt.push(e)
    }

    function Mt(e) {
        Tt.push(e)
    }

    function Nt(e) {
        Ot.push(e)
    }

    function kt(e, t, r) {
        e._x_attributeCleanups || (e._x_attributeCleanups = {}), e._x_attributeCleanups[t] || (e._x_attributeCleanups[t] = []), e._x_attributeCleanups[t].push(r)
    }

    function Be(e, t) {
        !e._x_attributeCleanups || Object.entries(e._x_attributeCleanups).forEach(([r, n]) => {
            (t === void 0 || t.includes(r)) && (n.forEach(i => i()), delete e._x_attributeCleanups[r])
        })
    }
    var qe = new MutationObserver(He),
        Ue = !1;

    function We() {
        qe.observe(document, {
            subtree: !0,
            childList: !0,
            attributes: !0,
            attributeOldValue: !0
        }), Ue = !0
    }

    function Hr() {
        Br(), qe.disconnect(), Ue = !1
    }
    var Z = [],
        Ge = !1;

    function Br() {
        Z = Z.concat(qe.takeRecords()), Z.length && !Ge && (Ge = !0, queueMicrotask(() => {
            qr(), Ge = !1
        }))
    }

    function qr() {
        He(Z), Z.length = 0
    }

    function m(e) {
        if (!Ue) return e();
        Hr();
        let t = e();
        return We(), t
    }
    var Ye = !1,
        pe = [];

    function Dt() {
        Ye = !0
    }

    function Pt() {
        Ye = !1, He(pe), pe = []
    }

    function He(e) {
        if (Ye) {
            pe = pe.concat(e);
            return
        }
        let t = [],
            r = [],
            n = new Map,
            i = new Map;
        for (let o = 0; o < e.length; o++)
            if (!e[o].target._x_ignoreMutationObserver && (e[o].type === "childList" && (e[o].addedNodes.forEach(s => s.nodeType === 1 && t.push(s)), e[o].removedNodes.forEach(s => s.nodeType === 1 && r.push(s))), e[o].type === "attributes")) {
                let s = e[o].target,
                    a = e[o].attributeName,
                    c = e[o].oldValue,
                    l = () => {
                        n.has(s) || n.set(s, []), n.get(s).push({
                            name: a,
                            value: s.getAttribute(a)
                        })
                    },
                    u = () => {
                        i.has(s) || i.set(s, []), i.get(s).push(a)
                    };
                s.hasAttribute(a) && c === null ? l() : s.hasAttribute(a) ? (u(), l()) : u()
            } i.forEach((o, s) => {
            Be(s, o)
        }), n.forEach((o, s) => {
            Ot.forEach(a => a(s, o))
        });
        for (let o of t) r.includes(o) || Rt.forEach(s => s(o));
        for (let o of r) t.includes(o) || Tt.forEach(s => s(o));
        t = null, r = null, n = null, i = null
    }

    function B(e, t, r) {
        return e._x_dataStack = [t, ...Q(r || e)], () => {
            e._x_dataStack = e._x_dataStack.filter(n => n !== t)
        }
    }

    function Je(e, t) {
        let r = e._x_dataStack[0];
        Object.entries(t).forEach(([n, i]) => {
            r[n] = i
        })
    }

    function Q(e) {
        return e._x_dataStack ? e._x_dataStack : typeof ShadowRoot == "function" && e instanceof ShadowRoot ? Q(e.host) : e.parentNode ? Q(e.parentNode) : []
    }

    function X(e) {
        let t = new Proxy({}, {
            ownKeys: () => Array.from(new Set(e.flatMap(r => Object.keys(r)))),
            has: (r, n) => e.some(i => i.hasOwnProperty(n)),
            get: (r, n) => (e.find(i => {
                if (i.hasOwnProperty(n)) {
                    let o = Object.getOwnPropertyDescriptor(i, n);
                    if (o.get && o.get._x_alreadyBound || o.set && o.set._x_alreadyBound) return !0;
                    if ((o.get || o.set) && o.enumerable) {
                        let s = o.get,
                            a = o.set,
                            c = o;
                        s = s && s.bind(t), a = a && a.bind(t), s && (s._x_alreadyBound = !0), a && (a._x_alreadyBound = !0), Object.defineProperty(i, n, {
                            ...c,
                            get: s,
                            set: a
                        })
                    }
                    return !0
                }
                return !1
            }) || {})[n],
            set: (r, n, i) => {
                let o = e.find(s => s.hasOwnProperty(n));
                return o ? o[n] = i : e[e.length - 1][n] = i, !0
            }
        });
        return t
    }

    function It(e) {
        let t = n => typeof n == "object" && !Array.isArray(n) && n !== null,
            r = (n, i = "") => {
                Object.entries(n).forEach(([o, s]) => {
                    let a = i === "" ? o : `${i}.${o}`;
                    typeof s == "object" && s !== null && s._x_interceptor ? n[o] = s.initialize(e, a, o) : t(s) && s !== n && !(s instanceof Element) && r(s, a)
                })
            };
        return r(e)
    }

    function me(e, t = () => {}) {
        let r = {
            initialValue: void 0,
            _x_interceptor: !0,
            initialize(n, i, o) {
                return e(this.initialValue, () => Ur(n, i), s => Ze(n, i, s), i, o)
            }
        };
        return t(r), n => {
            if (typeof n == "object" && n !== null && n._x_interceptor) {
                let i = r.initialize.bind(r);
                r.initialize = (o, s, a) => {
                    let c = n.initialize(o, s, a);
                    return r.initialValue = c, i(o, s, a)
                }
            } else r.initialValue = n;
            return r
        }
    }

    function Ur(e, t) {
        return t.split(".").reduce((r, n) => r[n], e)
    }

    function Ze(e, t, r) {
        if (typeof t == "string" && (t = t.split(".")), t.length === 1) e[t[0]] = r;
        else {
            if (t.length === 0) throw error;
            return e[t[0]] || (e[t[0]] = {}), Ze(e[t[0]], t.slice(1), r)
        }
    }
    var Lt = {};

    function x(e, t) {
        Lt[e] = t
    }

    function ee(e, t) {
        return Object.entries(Lt).forEach(([r, n]) => {
            Object.defineProperty(e, `$${r}`, {
                get() {
                    return n(t, {
                        Alpine: S,
                        interceptor: me
                    })
                },
                enumerable: !1
            })
        }), e
    }

    function b(e, t, r = {}) {
        let n;
        return h(e, t)(i => n = i, r), n
    }

    function h(...e) {
        return $t(...e)
    }
    var $t = Qe;

    function Ft(e) {
        $t = e
    }

    function Qe(e, t) {
        let r = {};
        ee(r, e);
        let n = [r, ...Q(e)];
        if (typeof t == "function") return Wr(n, t);
        let i = Gr(n, t);
        return Yr.bind(null, e, t, i)
    }

    function Wr(e, t) {
        return (r = () => {}, {
            scope: n = {},
            params: i = []
        } = {}) => {
            let o = t.apply(X([n, ...e]), i);
            he(r, o)
        }
    }
    var Xe = {};

    function Jr(e) {
        if (Xe[e]) return Xe[e];
        let t = Object.getPrototypeOf(async function () {}).constructor,
            r = /^[\n\s]*if.*\(.*\)/.test(e) || /^(let|const)/.test(e) ? `(() => { ${e} })()` : e,
            n = new t(["__self", "scope"], `with (scope) { __self.result = ${r} }; __self.finished = true; return __self.result;`);
        return Xe[e] = n, n
    }

    function Gr(e, t) {
        let r = Jr(t);
        return (n = () => {}, {
            scope: i = {},
            params: o = []
        } = {}) => {
            r.result = void 0, r.finished = !1;
            let s = X([i, ...e]),
                a = r(r, s);
            r.finished ? he(n, r.result, s, o) : a.then(c => {
                he(n, c, s, o)
            })
        }
    }

    function he(e, t, r, n) {
        if (typeof t == "function") {
            let i = t.apply(r, n);
            i instanceof Promise ? i.then(o => he(e, o, r, n)) : e(i)
        } else e(t)
    }

    function Yr(e, t, r, ...n) {
        try {
            return r(...n)
        } catch (i) {
            throw console.warn(`Alpine Expression Error: ${i.message}

Expression: "${t}"

`, e), i
        }
    }
    var et = "x-";

    function A(e = "") {
        return et + e
    }

    function jt(e) {
        et = e
    }
    var Kt = {};

    function p(e, t) {
        Kt[e] = t
    }

    function te(e, t, r) {
        let n = {};
        return Array.from(t).map(zt((o, s) => n[o] = s)).filter(Vt).map(Qr(n, r)).sort(Xr).map(o => Zr(e, o))
    }

    function Bt(e) {
        return Array.from(e).map(zt()).filter(t => !Vt(t))
    }
    var tt = !1,
        re = new Map,
        Ht = Symbol();

    function qt(e) {
        tt = !0;
        let t = Symbol();
        Ht = t, re.set(t, []);
        let r = () => {
                for (; re.get(t).length;) re.get(t).shift()();
                re.delete(t)
            },
            n = () => {
                tt = !1, r()
            };
        e(r), n()
    }

    function Zr(e, t) {
        let r = () => {},
            n = Kt[t.type] || r,
            i = [],
            o = d => i.push(d),
            [s, a] = At(e);
        i.push(a);
        let c = {
                Alpine: S,
                effect: s,
                cleanup: o,
                evaluateLater: h.bind(h, e),
                evaluate: b.bind(b, e)
            },
            l = () => i.forEach(d => d());
        kt(e, t.original, l);
        let u = () => {
            e._x_ignore || e._x_ignoreSelf || (n.inline && n.inline(e, t, c), n = n.bind(n, e, t, c), tt ? re.get(Ht).push(n) : n())
        };
        return u.runCleanups = l, u
    }
    var ge = (e, t) => ({
            name: r,
            value: n
        }) => (r.startsWith(e) && (r = r.replace(e, t)), {
            name: r,
            value: n
        }),
        _e = e => e;

    function zt(e = () => {}) {
        return ({
            name: t,
            value: r
        }) => {
            let {
                name: n,
                value: i
            } = Ut.reduce((o, s) => s(o), {
                name: t,
                value: r
            });
            return n !== t && e(n, t), {
                name: n,
                value: i
            }
        }
    }
    var Ut = [];

    function H(e) {
        Ut.push(e)
    }

    function Vt({
        name: e
    }) {
        return Wt().test(e)
    }
    var Wt = () => new RegExp(`^${et}([^:^.]+)\\b`);

    function Qr(e, t) {
        return ({
            name: r,
            value: n
        }) => {
            let i = r.match(Wt()),
                o = r.match(/:([a-zA-Z0-9\-:]+)/),
                s = r.match(/\.[^.\]]+(?=[^\]]*$)/g) || [],
                a = t || e[r] || r;
            return {
                type: i ? i[1] : null,
                value: o ? o[1] : null,
                modifiers: s.map(c => c.replace(".", "")),
                expression: n,
                original: a
            }
        }
    }
    var rt = "DEFAULT",
        ye = ["ignore", "ref", "data", "bind", "init", "for", "model", "transition", "show", "if", rt, "element"];

    function Xr(e, t) {
        let r = ye.indexOf(e.type) === -1 ? rt : e.type,
            n = ye.indexOf(t.type) === -1 ? rt : t.type;
        return ye.indexOf(r) - ye.indexOf(n)
    }

    function $(e, t, r = {}) {
        e.dispatchEvent(new CustomEvent(t, {
            detail: r,
            bubbles: !0,
            composed: !0,
            cancelable: !0
        }))
    }
    var nt = [],
        it = !1;

    function q(e) {
        nt.push(e), queueMicrotask(() => {
            it || setTimeout(() => {
                xe()
            })
        })
    }

    function xe() {
        for (it = !1; nt.length;) nt.shift()()
    }

    function Gt() {
        it = !0
    }

    function N(e, t) {
        if (typeof ShadowRoot == "function" && e instanceof ShadowRoot) {
            Array.from(e.children).forEach(i => N(i, t));
            return
        }
        let r = !1;
        if (t(e, () => r = !0), r) return;
        let n = e.firstElementChild;
        for (; n;) N(n, t, !1), n = n.nextElementSibling
    }

    function be(e, ...t) {
        console.warn(`Alpine Warning: ${e}`, ...t)
    }

    function Jt() {
        document.body || be("Unable to initialize. Trying to load Alpine before `<body>` is available. Did you forget to add `defer` in Alpine's `<script>` tag?"), $(document, "alpine:init"), $(document, "alpine:initializing"), We(), Ct(t => O(t, N)), Mt(t => q(() => en(t))), Nt((t, r) => {
            te(t, r).forEach(n => n())
        });
        let e = t => !k(t.parentElement, !0);
        Array.from(document.querySelectorAll(Yt())).filter(e).forEach(t => {
            O(t)
        }), $(document, "alpine:initialized")
    }
    var ot = [],
        Zt = [];

    function Qt() {
        return ot.map(e => e())
    }

    function Yt() {
        return ot.concat(Zt).map(e => e())
    }

    function ve(e) {
        ot.push(e)
    }

    function Xt(e) {
        Zt.push(e)
    }

    function k(e, t = !1) {
        if (!e) return;
        if ((t ? Yt() : Qt()).some(n => e.matches(n))) return e;
        if (!!e.parentElement) return k(e.parentElement, t)
    }

    function er(e) {
        return Qt().some(t => e.matches(t))
    }

    function O(e, t = N) {
        qt(() => {
            t(e, (r, n) => {
                te(r, r.attributes).forEach(i => i()), r._x_ignore && n()
            })
        })
    }

    function en(e) {
        N(e, t => Be(t))
    }

    function ne(e, t) {
        return Array.isArray(t) ? tr(e, t.join(" ")) : typeof t == "object" && t !== null ? tn(e, t) : typeof t == "function" ? ne(e, t()) : tr(e, t)
    }

    function tr(e, t) {
        let r = o => o.split(" ").filter(Boolean),
            n = o => o.split(" ").filter(s => !e.classList.contains(s)).filter(Boolean),
            i = o => (e.classList.add(...o), () => {
                e.classList.remove(...o)
            });
        return t = t === !0 ? t = "" : t || "", i(n(t))
    }

    function tn(e, t) {
        let r = a => a.split(" ").filter(Boolean),
            n = Object.entries(t).flatMap(([a, c]) => c ? r(a) : !1).filter(Boolean),
            i = Object.entries(t).flatMap(([a, c]) => c ? !1 : r(a)).filter(Boolean),
            o = [],
            s = [];
        return i.forEach(a => {
            e.classList.contains(a) && (e.classList.remove(a), s.push(a))
        }), n.forEach(a => {
            e.classList.contains(a) || (e.classList.add(a), o.push(a))
        }), () => {
            s.forEach(a => e.classList.add(a)), o.forEach(a => e.classList.remove(a))
        }
    }

    function F(e, t) {
        return typeof t == "object" && t !== null ? rn(e, t) : nn(e, t)
    }

    function rn(e, t) {
        let r = {};
        return Object.entries(t).forEach(([n, i]) => {
            r[n] = e.style[n], e.style.setProperty(on(n), i)
        }), setTimeout(() => {
            e.style.length === 0 && e.removeAttribute("style")
        }), () => {
            F(e, r)
        }
    }

    function nn(e, t) {
        let r = e.getAttribute("style", t);
        return e.setAttribute("style", t), () => {
            e.setAttribute("style", r)
        }
    }

    function on(e) {
        return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
    }

    function ie(e, t = () => {}) {
        let r = !1;
        return function () {
            r ? t.apply(this, arguments) : (r = !0, e.apply(this, arguments))
        }
    }
    p("transition", (e, {
        value: t,
        modifiers: r,
        expression: n
    }, {
        evaluate: i
    }) => {
        typeof n == "function" && (n = i(n)), n ? sn(e, n, t) : an(e, r, t)
    });

    function sn(e, t, r) {
        rr(e, ne, ""), {
            enter: i => {
                e._x_transition.enter.during = i
            },
            "enter-start": i => {
                e._x_transition.enter.start = i
            },
            "enter-end": i => {
                e._x_transition.enter.end = i
            },
            leave: i => {
                e._x_transition.leave.during = i
            },
            "leave-start": i => {
                e._x_transition.leave.start = i
            },
            "leave-end": i => {
                e._x_transition.leave.end = i
            }
        } [r](t)
    }

    function an(e, t, r) {
        rr(e, F);
        let n = !t.includes("in") && !t.includes("out") && !r,
            i = n || t.includes("in") || ["enter"].includes(r),
            o = n || t.includes("out") || ["leave"].includes(r);
        t.includes("in") && !n && (t = t.filter((_, y) => y < t.indexOf("out"))), t.includes("out") && !n && (t = t.filter((_, y) => y > t.indexOf("out")));
        let s = !t.includes("opacity") && !t.includes("scale"),
            a = s || t.includes("opacity"),
            c = s || t.includes("scale"),
            l = a ? 0 : 1,
            u = c ? oe(t, "scale", 95) / 100 : 1,
            d = oe(t, "delay", 0),
            E = oe(t, "origin", "center"),
            L = "opacity, transform",
            K = oe(t, "duration", 150) / 1e3,
            fe = oe(t, "duration", 75) / 1e3,
            f = "cubic-bezier(0.4, 0.0, 0.2, 1)";
        i && (e._x_transition.enter.during = {
            transformOrigin: E,
            transitionDelay: d,
            transitionProperty: L,
            transitionDuration: `${K}s`,
            transitionTimingFunction: f
        }, e._x_transition.enter.start = {
            opacity: l,
            transform: `scale(${u})`
        }, e._x_transition.enter.end = {
            opacity: 1,
            transform: "scale(1)"
        }), o && (e._x_transition.leave.during = {
            transformOrigin: E,
            transitionDelay: d,
            transitionProperty: L,
            transitionDuration: `${fe}s`,
            transitionTimingFunction: f
        }, e._x_transition.leave.start = {
            opacity: 1,
            transform: "scale(1)"
        }, e._x_transition.leave.end = {
            opacity: l,
            transform: `scale(${u})`
        })
    }

    function rr(e, t, r = {}) {
        e._x_transition || (e._x_transition = {
            enter: {
                during: r,
                start: r,
                end: r
            },
            leave: {
                during: r,
                start: r,
                end: r
            },
            in (n = () => {}, i = () => {}) {
                we(e, t, {
                    during: this.enter.during,
                    start: this.enter.start,
                    end: this.enter.end
                }, n, i)
            },
            out(n = () => {}, i = () => {}) {
                we(e, t, {
                    during: this.leave.during,
                    start: this.leave.start,
                    end: this.leave.end
                }, n, i)
            }
        })
    }
    window.Element.prototype._x_toggleAndCascadeWithTransitions = function (e, t, r, n) {
        let i = () => {
            document.visibilityState === "visible" ? requestAnimationFrame(r) : setTimeout(r)
        };
        if (t) {
            e._x_transition ? e._x_transition.in(r) : i();
            return
        }
        e._x_hidePromise = e._x_transition ? new Promise((o, s) => {
            e._x_transition.out(() => {}, () => o(n)), e._x_transitioning.beforeCancel(() => s({
                isFromCancelledTransition: !0
            }))
        }) : Promise.resolve(n), queueMicrotask(() => {
            let o = nr(e);
            o ? (o._x_hideChildren || (o._x_hideChildren = []), o._x_hideChildren.push(e)) : queueMicrotask(() => {
                let s = a => {
                    let c = Promise.all([a._x_hidePromise, ...(a._x_hideChildren || []).map(s)]).then(([l]) => l());
                    return delete a._x_hidePromise, delete a._x_hideChildren, c
                };
                s(e).catch(a => {
                    if (!a.isFromCancelledTransition) throw a
                })
            })
        })
    };

    function nr(e) {
        let t = e.parentNode;
        if (!!t) return t._x_hidePromise ? t : nr(t)
    }

    function we(e, t, {
        during: r,
        start: n,
        end: i
    } = {}, o = () => {}, s = () => {}) {
        if (e._x_transitioning && e._x_transitioning.cancel(), Object.keys(r).length === 0 && Object.keys(n).length === 0 && Object.keys(i).length === 0) {
            o(), s();
            return
        }
        let a, c, l;
        cn(e, {
            start() {
                a = t(e, n)
            },
            during() {
                c = t(e, r)
            },
            before: o,
            end() {
                a(), l = t(e, i)
            },
            after: s,
            cleanup() {
                c(), l()
            }
        })
    }

    function cn(e, t) {
        let r, n, i, o = ie(() => {
            m(() => {
                r = !0, n || t.before(), i || (t.end(), xe()), t.after(), e.isConnected && t.cleanup(), delete e._x_transitioning
            })
        });
        e._x_transitioning = {
            beforeCancels: [],
            beforeCancel(s) {
                this.beforeCancels.push(s)
            },
            cancel: ie(function () {
                for (; this.beforeCancels.length;) this.beforeCancels.shift()();
                o()
            }),
            finish: o
        }, m(() => {
            t.start(), t.during()
        }), Gt(), requestAnimationFrame(() => {
            if (r) return;
            let s = Number(getComputedStyle(e).transitionDuration.replace(/,.*/, "").replace("s", "")) * 1e3,
                a = Number(getComputedStyle(e).transitionDelay.replace(/,.*/, "").replace("s", "")) * 1e3;
            s === 0 && (s = Number(getComputedStyle(e).animationDuration.replace("s", "")) * 1e3), m(() => {
                t.before()
            }), n = !0, requestAnimationFrame(() => {
                r || (m(() => {
                    t.end()
                }), xe(), setTimeout(e._x_transitioning.finish, s + a), i = !0)
            })
        })
    }

    function oe(e, t, r) {
        if (e.indexOf(t) === -1) return r;
        let n = e[e.indexOf(t) + 1];
        if (!n || t === "scale" && isNaN(n)) return r;
        if (t === "duration") {
            let i = n.match(/([0-9]+)ms/);
            if (i) return i[1]
        }
        return t === "origin" && ["top", "right", "left", "center", "bottom"].includes(e[e.indexOf(t) + 2]) ? [n, e[e.indexOf(t) + 2]].join(" ") : n
    }

    function Ee(e, t) {
        var r;
        return function () {
            var n = this,
                i = arguments,
                o = function () {
                    r = null, e.apply(n, i)
                };
            clearTimeout(r), r = setTimeout(o, t)
        }
    }

    function Se(e, t) {
        let r;
        return function () {
            let n = this,
                i = arguments;
            r || (e.apply(n, i), r = !0, setTimeout(() => r = !1, t))
        }
    }

    function ir(e) {
        e(S)
    }
    var U = {},
        or = !1;

    function sr(e, t) {
        if (or || (U = v(U), or = !0), t === void 0) return U[e];
        U[e] = t, typeof t == "object" && t !== null && t.hasOwnProperty("init") && typeof t.init == "function" && U[e].init()
    }

    function ar() {
        return U
    }
    var st = !1;

    function W(e) {
        return (...t) => st || e(...t)
    }

    function cr(e, t) {
        t._x_dataStack = e._x_dataStack, st = !0, un(() => {
            ln(t)
        }), st = !1
    }

    function ln(e) {
        let t = !1;
        O(e, (n, i) => {
            N(n, (o, s) => {
                if (t && er(o)) return s();
                t = !0, i(o, s)
            })
        })
    }

    function un(e) {
        let t = C;
        Ve((r, n) => {
            let i = t(r);
            return V(i), () => {}
        }), e(), Ve(t)
    }
    var lr = {};

    function ur(e, t) {
        lr[e] = t
    }

    function fr(e, t) {
        return Object.entries(lr).forEach(([r, n]) => {
            Object.defineProperty(e, r, {
                get() {
                    return (...i) => n.bind(t)(...i)
                },
                enumerable: !1
            })
        }), e
    }
    var fn = {
            get reactive() {
                return v
            },
            get release() {
                return V
            },
            get effect() {
                return C
            },
            get raw() {
                return Ke
            },
            version: "3.4.2",
            flushAndStopDeferringMutations: Pt,
            disableEffectScheduling: Et,
            setReactivityEngine: St,
            addRootSelector: ve,
            deferMutations: Dt,
            mapAttributes: H,
            evaluateLater: h,
            setEvaluator: Ft,
            closestRoot: k,
            interceptor: me,
            transition: we,
            setStyles: F,
            mutateDom: m,
            directive: p,
            throttle: Se,
            debounce: Ee,
            evaluate: b,
            initTree: O,
            nextTick: q,
            prefix: jt,
            plugin: ir,
            magic: x,
            store: sr,
            start: Jt,
            clone: cr,
            data: ur
        },
        S = fn;

    function at(e, t) {
        let r = Object.create(null),
            n = e.split(",");
        for (let i = 0; i < n.length; i++) r[n[i]] = !0;
        return t ? i => !!r[i.toLowerCase()] : i => !!r[i]
    }
    var So = {
            [1]: "TEXT",
            [2]: "CLASS",
            [4]: "STYLE",
            [8]: "PROPS",
            [16]: "FULL_PROPS",
            [32]: "HYDRATE_EVENTS",
            [64]: "STABLE_FRAGMENT",
            [128]: "KEYED_FRAGMENT",
            [256]: "UNKEYED_FRAGMENT",
            [512]: "NEED_PATCH",
            [1024]: "DYNAMIC_SLOTS",
            [2048]: "DEV_ROOT_FRAGMENT",
            [-1]: "HOISTED",
            [-2]: "BAIL"
        },
        Ao = {
            [1]: "STABLE",
            [2]: "DYNAMIC",
            [3]: "FORWARDED"
        };
    var dn = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly";
    var Oo = at(dn + ",async,autofocus,autoplay,controls,default,defer,disabled,hidden,loop,open,required,reversed,scoped,seamless,checked,muted,multiple,selected");
    var dr = Object.freeze({}),
        To = Object.freeze([]);
    var ct = Object.assign;
    var pn = Object.prototype.hasOwnProperty,
        se = (e, t) => pn.call(e, t),
        D = Array.isArray,
        G = e => pr(e) === "[object Map]";
    var mn = e => typeof e == "string",
        Ae = e => typeof e == "symbol",
        ae = e => e !== null && typeof e == "object";
    var hn = Object.prototype.toString,
        pr = e => hn.call(e),
        lt = e => pr(e).slice(8, -1);
    var Oe = e => mn(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e;
    var Te = e => {
            let t = Object.create(null);
            return r => t[r] || (t[r] = e(r))
        },
        gn = /-(\w)/g,
        Ro = Te(e => e.replace(gn, (t, r) => r ? r.toUpperCase() : "")),
        _n = /\B([A-Z])/g,
        Co = Te(e => e.replace(_n, "-$1").toLowerCase()),
        ut = Te(e => e.charAt(0).toUpperCase() + e.slice(1)),
        Mo = Te(e => e ? `on${ut(e)}` : ""),
        ft = (e, t) => e !== t && (e === e || t === t);
    var dt = new WeakMap,
        ce = [],
        T, j = Symbol("iterate"),
        pt = Symbol("Map key iterate");

    function yn(e) {
        return e && e._isEffect === !0
    }

    function mr(e, t = dr) {
        yn(e) && (e = e.raw);
        let r = xn(e, t);
        return t.lazy || r(), r
    }

    function gr(e) {
        e.active && (hr(e), e.options.onStop && e.options.onStop(), e.active = !1)
    }
    var bn = 0;

    function xn(e, t) {
        let r = function () {
            if (!r.active) return e();
            if (!ce.includes(r)) {
                hr(r);
                try {
                    return vn(), ce.push(r), T = r, e()
                } finally {
                    ce.pop(), _r(), T = ce[ce.length - 1]
                }
            }
        };
        return r.id = bn++, r.allowRecurse = !!t.allowRecurse, r._isEffect = !0, r.active = !0, r.raw = e, r.deps = [], r.options = t, r
    }

    function hr(e) {
        let {
            deps: t
        } = e;
        if (t.length) {
            for (let r = 0; r < t.length; r++) t[r].delete(e);
            t.length = 0
        }
    }
    var Y = !0,
        mt = [];

    function wn() {
        mt.push(Y), Y = !1
    }

    function vn() {
        mt.push(Y), Y = !0
    }

    function _r() {
        let e = mt.pop();
        Y = e === void 0 ? !0 : e
    }

    function w(e, t, r) {
        if (!Y || T === void 0) return;
        let n = dt.get(e);
        n || dt.set(e, n = new Map);
        let i = n.get(r);
        i || n.set(r, i = new Set), i.has(T) || (i.add(T), T.deps.push(i), T.options.onTrack && T.options.onTrack({
            effect: T,
            target: e,
            type: t,
            key: r
        }))
    }

    function P(e, t, r, n, i, o) {
        let s = dt.get(e);
        if (!s) return;
        let a = new Set,
            c = u => {
                u && u.forEach(d => {
                    (d !== T || d.allowRecurse) && a.add(d)
                })
            };
        if (t === "clear") s.forEach(c);
        else if (r === "length" && D(e)) s.forEach((u, d) => {
            (d === "length" || d >= n) && c(u)
        });
        else switch (r !== void 0 && c(s.get(r)), t) {
            case "add":
                D(e) ? Oe(r) && c(s.get("length")) : (c(s.get(j)), G(e) && c(s.get(pt)));
                break;
            case "delete":
                D(e) || (c(s.get(j)), G(e) && c(s.get(pt)));
                break;
            case "set":
                G(e) && c(s.get(j));
                break
        }
        let l = u => {
            u.options.onTrigger && u.options.onTrigger({
                effect: u,
                target: e,
                key: r,
                type: t,
                newValue: n,
                oldValue: i,
                oldTarget: o
            }), u.options.scheduler ? u.options.scheduler(u) : u()
        };
        a.forEach(l)
    }
    var En = at("__proto__,__v_isRef,__isVue"),
        yr = new Set(Object.getOwnPropertyNames(Symbol).map(e => Symbol[e]).filter(Ae)),
        Sn = Re(),
        An = Re(!1, !0),
        On = Re(!0),
        Tn = Re(!0, !0),
        Ce = {};
    ["includes", "indexOf", "lastIndexOf"].forEach(e => {
        let t = Array.prototype[e];
        Ce[e] = function (...r) {
            let n = g(this);
            for (let o = 0, s = this.length; o < s; o++) w(n, "get", o + "");
            let i = t.apply(n, r);
            return i === -1 || i === !1 ? t.apply(n, r.map(g)) : i
        }
    });
    ["push", "pop", "shift", "unshift", "splice"].forEach(e => {
        let t = Array.prototype[e];
        Ce[e] = function (...r) {
            wn();
            let n = t.apply(this, r);
            return _r(), n
        }
    });

    function Re(e = !1, t = !1) {
        return function (n, i, o) {
            if (i === "__v_isReactive") return !e;
            if (i === "__v_isReadonly") return e;
            if (i === "__v_raw" && o === (e ? t ? Cn : br : t ? Rn : xr).get(n)) return n;
            let s = D(n);
            if (!e && s && se(Ce, i)) return Reflect.get(Ce, i, o);
            let a = Reflect.get(n, i, o);
            return (Ae(i) ? yr.has(i) : En(i)) || (e || w(n, "get", i), t) ? a : ht(a) ? !s || !Oe(i) ? a.value : a : ae(a) ? e ? vr(a) : Me(a) : a
        }
    }
    var Mn = wr(),
        Nn = wr(!0);

    function wr(e = !1) {
        return function (r, n, i, o) {
            let s = r[n];
            if (!e && (i = g(i), s = g(s), !D(r) && ht(s) && !ht(i))) return s.value = i, !0;
            let a = D(r) && Oe(n) ? Number(n) < r.length : se(r, n),
                c = Reflect.set(r, n, i, o);
            return r === g(o) && (a ? ft(i, s) && P(r, "set", n, i, s) : P(r, "add", n, i)), c
        }
    }

    function kn(e, t) {
        let r = se(e, t),
            n = e[t],
            i = Reflect.deleteProperty(e, t);
        return i && r && P(e, "delete", t, void 0, n), i
    }

    function Dn(e, t) {
        let r = Reflect.has(e, t);
        return (!Ae(t) || !yr.has(t)) && w(e, "has", t), r
    }

    function Pn(e) {
        return w(e, "iterate", D(e) ? "length" : j), Reflect.ownKeys(e)
    }
    var Er = {
            get: Sn,
            set: Mn,
            deleteProperty: kn,
            has: Dn,
            ownKeys: Pn
        },
        Sr = {
            get: On,
            set(e, t) {
                return console.warn(`Set operation on key "${String(t)}" failed: target is readonly.`, e), !0
            },
            deleteProperty(e, t) {
                return console.warn(`Delete operation on key "${String(t)}" failed: target is readonly.`, e), !0
            }
        },
        Lo = ct({}, Er, {
            get: An,
            set: Nn
        }),
        $o = ct({}, Sr, {
            get: Tn
        }),
        gt = e => ae(e) ? Me(e) : e,
        _t = e => ae(e) ? vr(e) : e,
        yt = e => e,
        Ne = e => Reflect.getPrototypeOf(e);

    function ke(e, t, r = !1, n = !1) {
        e = e.__v_raw;
        let i = g(e),
            o = g(t);
        t !== o && !r && w(i, "get", t), !r && w(i, "get", o);
        let {
            has: s
        } = Ne(i), a = n ? yt : r ? _t : gt;
        if (s.call(i, t)) return a(e.get(t));
        if (s.call(i, o)) return a(e.get(o));
        e !== i && e.get(t)
    }

    function De(e, t = !1) {
        let r = this.__v_raw,
            n = g(r),
            i = g(e);
        return e !== i && !t && w(n, "has", e), !t && w(n, "has", i), e === i ? r.has(e) : r.has(e) || r.has(i)
    }

    function Pe(e, t = !1) {
        return e = e.__v_raw, !t && w(g(e), "iterate", j), Reflect.get(e, "size", e)
    }

    function Ar(e) {
        e = g(e);
        let t = g(this);
        return Ne(t).has.call(t, e) || (t.add(e), P(t, "add", e, e)), this
    }

    function Tr(e, t) {
        t = g(t);
        let r = g(this),
            {
                has: n,
                get: i
            } = Ne(r),
            o = n.call(r, e);
        o ? Or(r, n, e) : (e = g(e), o = n.call(r, e));
        let s = i.call(r, e);
        return r.set(e, t), o ? ft(t, s) && P(r, "set", e, t, s) : P(r, "add", e, t), this
    }

    function Rr(e) {
        let t = g(this),
            {
                has: r,
                get: n
            } = Ne(t),
            i = r.call(t, e);
        i ? Or(t, r, e) : (e = g(e), i = r.call(t, e));
        let o = n ? n.call(t, e) : void 0,
            s = t.delete(e);
        return i && P(t, "delete", e, void 0, o), s
    }

    function Cr() {
        let e = g(this),
            t = e.size !== 0,
            r = G(e) ? new Map(e) : new Set(e),
            n = e.clear();
        return t && P(e, "clear", void 0, void 0, r), n
    }

    function Ie(e, t) {
        return function (n, i) {
            let o = this,
                s = o.__v_raw,
                a = g(s),
                c = t ? yt : e ? _t : gt;
            return !e && w(a, "iterate", j), s.forEach((l, u) => n.call(i, c(l), c(u), o))
        }
    }

    function Le(e, t, r) {
        return function (...n) {
            let i = this.__v_raw,
                o = g(i),
                s = G(o),
                a = e === "entries" || e === Symbol.iterator && s,
                c = e === "keys" && s,
                l = i[e](...n),
                u = r ? yt : t ? _t : gt;
            return !t && w(o, "iterate", c ? pt : j), {
                next() {
                    let {
                        value: d,
                        done: E
                    } = l.next();
                    return E ? {
                        value: d,
                        done: E
                    } : {
                        value: a ? [u(d[0]), u(d[1])] : u(d),
                        done: E
                    }
                },
                [Symbol.iterator]() {
                    return this
                }
            }
        }
    }

    function I(e) {
        return function (...t) {
            {
                let r = t[0] ? `on key "${t[0]}" ` : "";
                console.warn(`${ut(e)} operation ${r}failed: target is readonly.`, g(this))
            }
            return e === "delete" ? !1 : this
        }
    }
    var Mr = {
            get(e) {
                return ke(this, e)
            },
            get size() {
                return Pe(this)
            },
            has: De,
            add: Ar,
            set: Tr,
            delete: Rr,
            clear: Cr,
            forEach: Ie(!1, !1)
        },
        Nr = {
            get(e) {
                return ke(this, e, !1, !0)
            },
            get size() {
                return Pe(this)
            },
            has: De,
            add: Ar,
            set: Tr,
            delete: Rr,
            clear: Cr,
            forEach: Ie(!1, !0)
        },
        kr = {
            get(e) {
                return ke(this, e, !0)
            },
            get size() {
                return Pe(this, !0)
            },
            has(e) {
                return De.call(this, e, !0)
            },
            add: I("add"),
            set: I("set"),
            delete: I("delete"),
            clear: I("clear"),
            forEach: Ie(!0, !1)
        },
        Dr = {
            get(e) {
                return ke(this, e, !0, !0)
            },
            get size() {
                return Pe(this, !0)
            },
            has(e) {
                return De.call(this, e, !0)
            },
            add: I("add"),
            set: I("set"),
            delete: I("delete"),
            clear: I("clear"),
            forEach: Ie(!0, !0)
        },
        In = ["keys", "values", "entries", Symbol.iterator];
    In.forEach(e => {
        Mr[e] = Le(e, !1, !1), kr[e] = Le(e, !0, !1), Nr[e] = Le(e, !1, !0), Dr[e] = Le(e, !0, !0)
    });

    function $e(e, t) {
        let r = t ? e ? Dr : Nr : e ? kr : Mr;
        return (n, i, o) => i === "__v_isReactive" ? !e : i === "__v_isReadonly" ? e : i === "__v_raw" ? n : Reflect.get(se(r, i) && i in n ? r : n, i, o)
    }
    var Ln = {
            get: $e(!1, !1)
        },
        Fo = {
            get: $e(!1, !0)
        },
        $n = {
            get: $e(!0, !1)
        },
        jo = {
            get: $e(!0, !0)
        };

    function Or(e, t, r) {
        let n = g(r);
        if (n !== r && t.call(e, n)) {
            let i = lt(e);
            console.warn(`Reactive ${i} contains both the raw and reactive versions of the same object${i==="Map"?" as keys":""}, which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible.`)
        }
    }
    var xr = new WeakMap,
        Rn = new WeakMap,
        br = new WeakMap,
        Cn = new WeakMap;

    function Fn(e) {
        switch (e) {
            case "Object":
            case "Array":
                return 1;
            case "Map":
            case "Set":
            case "WeakMap":
            case "WeakSet":
                return 2;
            default:
                return 0
        }
    }

    function jn(e) {
        return e.__v_skip || !Object.isExtensible(e) ? 0 : Fn(lt(e))
    }

    function Me(e) {
        return e && e.__v_isReadonly ? e : Pr(e, !1, Er, Ln, xr)
    }

    function vr(e) {
        return Pr(e, !0, Sr, $n, br)
    }

    function Pr(e, t, r, n, i) {
        if (!ae(e)) return console.warn(`value cannot be made reactive: ${String(e)}`), e;
        if (e.__v_raw && !(t && e.__v_isReactive)) return e;
        let o = i.get(e);
        if (o) return o;
        let s = jn(e);
        if (s === 0) return e;
        let a = new Proxy(e, s === 2 ? n : r);
        return i.set(e, a), a
    }

    function g(e) {
        return e && g(e.__v_raw) || e
    }

    function ht(e) {
        return Boolean(e && e.__v_isRef === !0)
    }
    x("nextTick", () => q);
    x("dispatch", e => $.bind($, e));
    x("watch", e => (t, r) => {
        let n = h(e, t),
            i = !0,
            o;
        C(() => n(s => {
            let a = document.createElement("div");
            a.dataset.throwAway = s, i ? o = s : queueMicrotask(() => {
                r(s, o), o = s
            }), i = !1
        }))
    });
    x("store", ar);
    x("root", e => k(e));
    x("refs", e => (e._x_refs_proxy || (e._x_refs_proxy = X(Kn(e))), e._x_refs_proxy));

    function Kn(e) {
        let t = [],
            r = e;
        for (; r;) r._x_refs && t.push(r._x_refs), r = r.parentNode;
        return t
    }
    x("el", e => e);
    var Ir = () => {};
    Ir.inline = (e, {
        modifiers: t
    }, {
        cleanup: r
    }) => {
        t.includes("self") ? e._x_ignoreSelf = !0 : e._x_ignore = !0, r(() => {
            t.includes("self") ? delete e._x_ignoreSelf : delete e._x_ignore
        })
    };
    p("ignore", Ir);
    p("effect", (e, {
        expression: t
    }, {
        effect: r
    }) => r(h(e, t)));

    function le(e, t, r, n = []) {
        switch (e._x_bindings || (e._x_bindings = v({})), e._x_bindings[t] = r, t = n.includes("camel") ? qn(t) : t, t) {
            case "value":
                zn(e, r);
                break;
            case "style":
                Bn(e, r);
                break;
            case "class":
                Vn(e, r);
                break;
            default:
                Hn(e, t, r);
                break
        }
    }

    function zn(e, t) {
        if (e.type === "radio") e.attributes.value === void 0 && (e.value = t), window.fromModel && (e.checked = Lr(e.value, t));
        else if (e.type === "checkbox") Number.isInteger(t) ? e.value = t : !Number.isInteger(t) && !Array.isArray(t) && typeof t != "boolean" && ![null, void 0].includes(t) ? e.value = String(t) : Array.isArray(t) ? e.checked = t.some(r => Lr(r, e.value)) : e.checked = !!t;
        else if (e.tagName === "SELECT") Un(e, t);
        else {
            if (e.value === t) return;
            e.value = t
        }
    }

    function Vn(e, t) {
        e._x_undoAddedClasses && e._x_undoAddedClasses(), e._x_undoAddedClasses = ne(e, t)
    }

    function Bn(e, t) {
        e._x_undoAddedStyles && e._x_undoAddedStyles(), e._x_undoAddedStyles = F(e, t)
    }

    function Hn(e, t, r) {
        [null, void 0, !1].includes(r) && Yn(t) ? e.removeAttribute(t) : (Gn(t) && (r = t), Wn(e, t, r))
    }

    function Wn(e, t, r) {
        e.getAttribute(t) != r && e.setAttribute(t, r)
    }

    function Un(e, t) {
        let r = [].concat(t).map(n => n + "");
        Array.from(e.options).forEach(n => {
            n.selected = r.includes(n.value)
        })
    }

    function qn(e) {
        return e.toLowerCase().replace(/-(\w)/g, (t, r) => r.toUpperCase())
    }

    function Lr(e, t) {
        return e == t
    }

    function Gn(e) {
        return ["disabled", "checked", "required", "readonly", "hidden", "open", "selected", "autofocus", "itemscope", "multiple", "novalidate", "allowfullscreen", "allowpaymentrequest", "formnovalidate", "autoplay", "controls", "loop", "muted", "playsinline", "default", "ismap", "reversed", "async", "defer", "nomodule"].includes(e)
    }

    function Yn(e) {
        return !["aria-pressed", "aria-checked", "aria-expanded"].includes(e)
    }

    function ue(e, t, r, n) {
        let i = e,
            o = c => n(c),
            s = {},
            a = (c, l) => u => l(c, u);
        if (r.includes("dot") && (t = Jn(t)), r.includes("camel") && (t = Zn(t)), r.includes("passive") && (s.passive = !0), r.includes("capture") && (s.capture = !0), r.includes("window") && (i = window), r.includes("document") && (i = document), r.includes("prevent") && (o = a(o, (c, l) => {
                l.preventDefault(), c(l)
            })), r.includes("stop") && (o = a(o, (c, l) => {
                l.stopPropagation(), c(l)
            })), r.includes("self") && (o = a(o, (c, l) => {
                l.target === e && c(l)
            })), (r.includes("away") || r.includes("outside")) && (i = document, o = a(o, (c, l) => {
                e.contains(l.target) || e.offsetWidth < 1 && e.offsetHeight < 1 || c(l)
            })), o = a(o, (c, l) => {
                Qn(t) && Xn(l, r) || c(l)
            }), r.includes("debounce")) {
            let c = r[r.indexOf("debounce") + 1] || "invalid-wait",
                l = xt(c.split("ms")[0]) ? Number(c.split("ms")[0]) : 250;
            o = Ee(o, l)
        }
        if (r.includes("throttle")) {
            let c = r[r.indexOf("throttle") + 1] || "invalid-wait",
                l = xt(c.split("ms")[0]) ? Number(c.split("ms")[0]) : 250;
            o = Se(o, l)
        }
        return r.includes("once") && (o = a(o, (c, l) => {
            c(l), i.removeEventListener(t, o, s)
        })), i.addEventListener(t, o, s), () => {
            i.removeEventListener(t, o, s)
        }
    }

    function Jn(e) {
        return e.replace(/-/g, ".")
    }

    function Zn(e) {
        return e.toLowerCase().replace(/-(\w)/g, (t, r) => r.toUpperCase())
    }

    function xt(e) {
        return !Array.isArray(e) && !isNaN(e)
    }

    function ei(e) {
        return e.replace(/([a-z])([A-Z])/g, "$1-$2").replace(/[_\s]/, "-").toLowerCase()
    }

    function Qn(e) {
        return ["keydown", "keyup"].includes(e)
    }

    function Xn(e, t) {
        let r = t.filter(o => !["window", "document", "prevent", "stop", "once"].includes(o));
        if (r.includes("debounce")) {
            let o = r.indexOf("debounce");
            r.splice(o, xt((r[o + 1] || "invalid-wait").split("ms")[0]) ? 2 : 1)
        }
        if (r.length === 0 || r.length === 1 && $r(e.key).includes(r[0])) return !1;
        let i = ["ctrl", "shift", "alt", "meta", "cmd", "super"].filter(o => r.includes(o));
        return r = r.filter(o => !i.includes(o)), !(i.length > 0 && i.filter(s => ((s === "cmd" || s === "super") && (s = "meta"), e[`${s}Key`])).length === i.length && $r(e.key).includes(r[0]))
    }

    function $r(e) {
        if (!e) return [];
        e = ei(e);
        let t = {
            ctrl: "control",
            slash: "/",
            space: "-",
            spacebar: "-",
            cmd: "meta",
            esc: "escape",
            up: "arrow-up",
            down: "arrow-down",
            left: "arrow-left",
            right: "arrow-right",
            period: ".",
            equal: "="
        };
        return t[e] = e, Object.keys(t).map(r => {
            if (t[r] === e) return r
        }).filter(r => r)
    }
    p("model", (e, {
        modifiers: t,
        expression: r
    }, {
        effect: n,
        cleanup: i
    }) => {
        let o = h(e, r),
            s = `${r} = rightSideOfExpression($event, ${r})`,
            a = h(e, s);
        var c = e.tagName.toLowerCase() === "select" || ["checkbox", "radio"].includes(e.type) || t.includes("lazy") ? "change" : "input";
        let l = ti(e, t, r),
            u = ue(e, c, t, d => {
                a(() => {}, {
                    scope: {
                        $event: d,
                        rightSideOfExpression: l
                    }
                })
            });
        i(() => u()), e._x_forceModelUpdate = () => {
            o(d => {
                d === void 0 && r.match(/\./) && (d = ""), window.fromModel = !0, m(() => le(e, "value", d)), delete window.fromModel
            })
        }, n(() => {
            t.includes("unintrusive") && document.activeElement.isSameNode(e) || e._x_forceModelUpdate()
        })
    });

    function ti(e, t, r) {
        return e.type === "radio" && m(() => {
            e.hasAttribute("name") || e.setAttribute("name", r)
        }), (n, i) => m(() => {
            if (n instanceof CustomEvent && n.detail !== void 0) return n.detail || n.target.value;
            if (e.type === "checkbox")
                if (Array.isArray(i)) {
                    let o = t.includes("number") ? bt(n.target.value) : n.target.value;
                    return n.target.checked ? i.concat([o]) : i.filter(s => !ri(s, o))
                } else return n.target.checked;
            else {
                if (e.tagName.toLowerCase() === "select" && e.multiple) return t.includes("number") ? Array.from(n.target.selectedOptions).map(o => {
                    let s = o.value || o.text;
                    return bt(s)
                }) : Array.from(n.target.selectedOptions).map(o => o.value || o.text); {
                    let o = n.target.value;
                    return t.includes("number") ? bt(o) : t.includes("trim") ? o.trim() : o
                }
            }
        })
    }

    function bt(e) {
        let t = e ? parseFloat(e) : null;
        return ni(t) ? t : e
    }

    function ri(e, t) {
        return e == t
    }

    function ni(e) {
        return !Array.isArray(e) && !isNaN(e)
    }
    p("cloak", e => queueMicrotask(() => m(() => e.removeAttribute(A("cloak")))));
    Xt(() => `[${A("init")}]`);
    p("init", W((e, {
        expression: t
    }) => typeof t == "string" ? !!t.trim() && b(e, t, {}, !1) : b(e, t, {}, !1)));
    p("text", (e, {
        expression: t
    }, {
        effect: r,
        evaluateLater: n
    }) => {
        let i = n(t);
        r(() => {
            i(o => {
                m(() => {
                    e.textContent = o
                })
            })
        })
    });
    p("html", (e, {
        expression: t
    }, {
        effect: r,
        evaluateLater: n
    }) => {
        let i = n(t);
        r(() => {
            i(o => {
                e.innerHTML = o
            })
        })
    });
    H(ge(":", _e(A("bind:"))));
    p("bind", (e, {
        value: t,
        modifiers: r,
        expression: n,
        original: i
    }, {
        effect: o
    }) => {
        if (!t) return ii(e, n, i, o);
        if (t === "key") return oi(e, n);
        let s = h(e, n);
        o(() => s(a => {
            a === void 0 && n.match(/\./) && (a = ""), m(() => le(e, t, a, r))
        }))
    });

    function ii(e, t, r, n) {
        let i = h(e, t),
            o = [];
        n(() => {
            for (; o.length;) o.pop()();
            i(s => {
                let a = Object.entries(s).map(([c, l]) => ({
                    name: c,
                    value: l
                }));
                Bt(a).forEach(({
                    name: c,
                    value: l
                }, u) => {
                    a[u] = {
                        name: `x-bind:${c}`,
                        value: `"${l}"`
                    }
                }), te(e, a, r).map(c => {
                    o.push(c.runCleanups), c()
                })
            })
        })
    }

    function oi(e, t) {
        e._x_keyExpression = t
    }
    ve(() => `[${A("data")}]`);
    p("data", W((e, {
        expression: t
    }, {
        cleanup: r
    }) => {
        t = t === "" ? "{}" : t;
        let n = {};
        ee(n, e);
        let i = {};
        fr(i, n);
        let o = b(e, t, {
            scope: i
        });
        ee(o, e);
        let s = v(o);
        It(s);
        let a = B(e, s);
        s.init && b(e, s.init), r(() => {
            a(), s.destroy && b(e, s.destroy)
        })
    }));
    p("show", (e, {
        modifiers: t,
        expression: r
    }, {
        effect: n
    }) => {
        let i = h(e, r),
            o = () => m(() => {
                e.style.display = "none", e._x_isShown = !1
            }),
            s = () => m(() => {
                e.style.length === 1 && e.style.display === "none" ? e.removeAttribute("style") : e.style.removeProperty("display"), e._x_isShown = !0
            }),
            a = () => setTimeout(s),
            c = ie(d => d ? s() : o(), d => {
                typeof e._x_toggleAndCascadeWithTransitions == "function" ? e._x_toggleAndCascadeWithTransitions(e, d, s, o) : d ? a() : o()
            }),
            l, u = !0;
        n(() => i(d => {
            !u && d === l || (t.includes("immediate") && (d ? a() : o()), c(d), l = d, u = !1)
        }))
    });
    p("for", (e, {
        expression: t
    }, {
        effect: r,
        cleanup: n
    }) => {
        let i = ai(t),
            o = h(e, i.items),
            s = h(e, e._x_keyExpression || "index");
        e._x_prevKeys = [], e._x_lookup = {}, r(() => si(e, i, o, s)), n(() => {
            Object.values(e._x_lookup).forEach(a => a.remove()), delete e._x_prevKeys, delete e._x_lookup
        })
    });

    function si(e, t, r, n) {
        let i = s => typeof s == "object" && !Array.isArray(s),
            o = e;
        r(s => {
            ci(s) && s >= 0 && (s = Array.from(Array(s).keys(), f => f + 1)), s === void 0 && (s = []);
            let a = e._x_lookup,
                c = e._x_prevKeys,
                l = [],
                u = [];
            if (i(s)) s = Object.entries(s).map(([f, _]) => {
                let y = Fr(t, _, f, s);
                n(R => u.push(R), {
                    scope: {
                        index: f,
                        ...y
                    }
                }), l.push(y)
            });
            else
                for (let f = 0; f < s.length; f++) {
                    let _ = Fr(t, s[f], f, s);
                    n(y => u.push(y), {
                        scope: {
                            index: f,
                            ..._
                        }
                    }), l.push(_)
                }
            let d = [],
                E = [],
                L = [],
                K = [];
            for (let f = 0; f < c.length; f++) {
                let _ = c[f];
                u.indexOf(_) === -1 && L.push(_)
            }
            c = c.filter(f => !L.includes(f));
            let fe = "template";
            for (let f = 0; f < u.length; f++) {
                let _ = u[f],
                    y = c.indexOf(_);
                if (y === -1) c.splice(f, 0, _), d.push([fe, f]);
                else if (y !== f) {
                    let R = c.splice(f, 1)[0],
                        M = c.splice(y - 1, 1)[0];
                    c.splice(f, 0, M), c.splice(y, 0, R), E.push([R, M])
                } else K.push(_);
                fe = _
            }
            for (let f = 0; f < L.length; f++) {
                let _ = L[f];
                a[_].remove(), a[_] = null, delete a[_]
            }
            for (let f = 0; f < E.length; f++) {
                let [_, y] = E[f], R = a[_], M = a[y], z = document.createElement("div");
                m(() => {
                    M.after(z), R.after(M), z.before(R), z.remove()
                }), Je(M, l[u.indexOf(y)])
            }
            for (let f = 0; f < d.length; f++) {
                let [_, y] = d[f], R = _ === "template" ? o : a[_], M = l[y], z = u[y], de = document.importNode(o.content, !0).firstElementChild;
                B(de, v(M), o), m(() => {
                    R.after(de), O(de)
                }), typeof z == "object" && be("x-for key cannot be an object, it must be a string or an integer", o), a[z] = de
            }
            for (let f = 0; f < K.length; f++) Je(a[K[f]], l[u.indexOf(K[f])]);
            o._x_prevKeys = u
        })
    }

    function ai(e) {
        let t = /,([^,\}\]]*)(?:,([^,\}\]]*))?$/,
            r = /^\s*\(|\)\s*$/g,
            n = /([\s\S]*?)\s+(?:in|of)\s+([\s\S]*)/,
            i = e.match(n);
        if (!i) return;
        let o = {};
        o.items = i[2].trim();
        let s = i[1].replace(r, "").trim(),
            a = s.match(t);
        return a ? (o.item = s.replace(t, "").trim(), o.index = a[1].trim(), a[2] && (o.collection = a[2].trim())) : o.item = s, o
    }

    function Fr(e, t, r, n) {
        let i = {};
        return /^\[.*\]$/.test(e.item) && Array.isArray(t) ? e.item.replace("[", "").replace("]", "").split(",").map(s => s.trim()).forEach((s, a) => {
            i[s] = t[a]
        }) : /^\{.*\}$/.test(e.item) && !Array.isArray(t) && typeof t == "object" ? e.item.replace("{", "").replace("}", "").split(",").map(s => s.trim()).forEach(s => {
            i[s] = t[s]
        }) : i[e.item] = t, e.index && (i[e.index] = r), e.collection && (i[e.collection] = n), i
    }

    function ci(e) {
        return !Array.isArray(e) && !isNaN(e)
    }

    function jr() {}
    jr.inline = (e, {
        expression: t
    }, {
        cleanup: r
    }) => {
        let n = k(e);
        n._x_refs || (n._x_refs = {}), n._x_refs[t] = e, r(() => delete n._x_refs[t])
    };
    p("ref", jr);
    p("if", (e, {
        expression: t
    }, {
        effect: r,
        cleanup: n
    }) => {
        let i = h(e, t),
            o = () => {
                if (e._x_currentIfEl) return e._x_currentIfEl;
                let a = e.content.cloneNode(!0).firstElementChild;
                return B(a, {}, e), m(() => {
                    e.after(a), O(a)
                }), e._x_currentIfEl = a, e._x_undoIf = () => {
                    a.remove(), delete e._x_currentIfEl
                }, a
            },
            s = () => {
                !e._x_undoIf || (e._x_undoIf(), delete e._x_undoIf)
            };
        r(() => i(a => {
            a ? o() : s()
        })), n(() => e._x_undoIf && e._x_undoIf())
    });
    H(ge("@", _e(A("on:"))));
    p("on", W((e, {
        value: t,
        modifiers: r,
        expression: n
    }, {
        cleanup: i
    }) => {
        let o = n ? h(e, n) : () => {},
            s = ue(e, t, r, a => {
                o(() => {}, {
                    scope: {
                        $event: a
                    },
                    params: [a]
                })
            });
        i(() => s())
    }));
    S.setEvaluator(Qe);
    S.setReactivityEngine({
        reactive: Me,
        effect: mr,
        release: gr,
        raw: g
    });
    var vt = S;
    window.Alpine = vt;
    queueMicrotask(() => {
        vt.start()
    });
})();