-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 11, 2021 at 07:45 AM
-- Server version: 5.6.51-cll-lve
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gungun_core`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add user', 7, 'add_user'),
(26, 'Can change user', 7, 'change_user'),
(27, 'Can delete user', 7, 'delete_user'),
(28, 'Can view user', 7, 'view_user'),
(29, 'Can add config', 8, 'add_config'),
(30, 'Can change config', 8, 'change_config'),
(31, 'Can delete config', 8, 'delete_config'),
(32, 'Can view config', 8, 'view_config'),
(33, 'Can add courses', 9, 'add_courses'),
(34, 'Can change courses', 9, 'change_courses'),
(35, 'Can delete courses', 9, 'delete_courses'),
(36, 'Can view courses', 9, 'view_courses'),
(37, 'Can add classes', 10, 'add_classes'),
(38, 'Can change classes', 10, 'change_classes'),
(39, 'Can delete classes', 10, 'delete_classes'),
(40, 'Can view classes', 10, 'view_classes'),
(41, 'Can add roles', 11, 'add_roles'),
(42, 'Can change roles', 11, 'change_roles'),
(43, 'Can delete roles', 11, 'delete_roles'),
(44, 'Can view roles', 11, 'view_roles');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$216000$Z41JHkePaM3I$4XIE105owXaAmJByypa7o478yLUe41c2uXZCkUYld0o=', '2021-11-10 19:18:38.840851', 1, 'super', '', '', 'super@gmail.com', 1, 1, '2021-11-09 17:47:29.036070');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2021-11-09 17:48:22.623413', '1', '', 1, '[{\"added\": {}}]', 7, 1),
(2, '2021-11-10 19:22:42.682922', 'e50bc7f4-f500-486c-9bfc-300442f1b85e', 'config object (e50bc7f4-f500-486c-9bfc-300442f1b85e)', 1, '[{\"added\": {}}]', 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(10, 'masters', 'classes'),
(8, 'masters', 'config'),
(9, 'masters', 'courses'),
(11, 'masters', 'roles'),
(6, 'sessions', 'session'),
(7, 'users', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-11-09 17:46:01.354182'),
(2, 'auth', '0001_initial', '2021-11-09 17:46:10.157783'),
(3, 'admin', '0001_initial', '2021-11-09 17:46:14.707824'),
(4, 'admin', '0002_logentry_remove_auto_add', '2021-11-09 17:46:15.321179'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-11-09 17:46:15.624600'),
(6, 'contenttypes', '0002_remove_content_type_name', '2021-11-09 17:46:16.684361'),
(7, 'auth', '0002_alter_permission_name_max_length', '2021-11-09 17:46:17.152349'),
(8, 'auth', '0003_alter_user_email_max_length', '2021-11-09 17:46:17.601346'),
(9, 'auth', '0004_alter_user_username_opts', '2021-11-09 17:46:17.905842'),
(10, 'auth', '0005_alter_user_last_login_null', '2021-11-09 17:46:18.377732'),
(11, 'auth', '0006_require_contenttypes_0002', '2021-11-09 17:46:18.663265'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2021-11-09 17:46:18.955260'),
(13, 'auth', '0008_alter_user_username_max_length', '2021-11-09 17:46:19.407217'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2021-11-09 17:46:19.868431'),
(15, 'auth', '0010_alter_group_name_max_length', '2021-11-09 17:46:20.325949'),
(16, 'auth', '0011_update_proxy_permissions', '2021-11-09 17:46:21.054651'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2021-11-09 17:46:21.514725'),
(18, 'sessions', '0001_initial', '2021-11-09 17:46:22.836380'),
(19, 'users', '0001_initial', '2021-11-09 17:46:26.716092'),
(20, 'masters', '0001_initial', '2021-11-09 18:18:06.961874');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('7alqwm8dc6hlfnb51ashp4qpng0ks0vy', '.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkrBs:WGv50BIGRfYbjY1-_I095SqI8rGgtXhMaYfyFJey5nM', '2021-11-24 17:15:16.932535'),
('7xcyxj060ikd08f3ijiduw06sw7o7s1i', '.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mlAZJ:KQNIcJ2CZTQ_kP0A4BEwgTchyci5xjWD3-U1tNWYTl4', '2021-11-25 13:56:45.144070'),
('8mgiaufd1j6qyav0dyr57p666nj4eii9', '.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkrPC:2E2El9oRpWz-sAtWV6jyisXIaf-EaWq5kwxd4uovC2k', '2021-11-24 17:29:02.198744'),
('c32bfohyab1bsnpcjcpzmhvkiyjhp8c5', '.eJxVjEsKwjAUAO-StYTm5WPi0r1nCO-T2Kq00LQr8e4S6EK3M8O8VcZ9G_PeyponURdl1OmXEfKzzF3IA-f7onmZt3Ui3RN92KZvi5TX9Wj_BiO2sW9TiexNcAn9kJhJBIKL3grh4Ax7BrQAtVY8swBQccYmomAtcElRfb7m2Tgk:1mkVDi:AQJhoKkRW3Ms_wAZvXr41FadOVZFGMkpSxdXv7yPu-k', '2021-11-23 17:47:42.017832'),
('gwdvti77gxnirjrwf9q423gebb6fsa48', '.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkVbT:2AjXdRGFsFut0JrklUN3LH0niGu_nwhLT2M3Z4CgOC4', '2021-11-23 18:12:15.104571'),
('rvtsmehli0vfvlcsul3apvmu39idcb0d', '.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mkrPE:HNqajUQbrKNhdr4WFfWXL2JRj0SJWPwzj8d6CINcOZE', '2021-11-24 17:29:04.147863'),
('xxz6fi6z1p0hwej6tch067yc6qehidef', '.eJwVi0EKgCAQAP-yZ1mwbhGRFf3DchPD1Ug9RX8vbzMD80BJdAfNBB2oaV56c-pgI5oNORryCQ9H3iRUJce14gACssu-Hknz9YMAYu28_Its2tFWwT0yvB819CAO:1mlAcW:peMl-sualBBBuVFqBaS2Yd-mkIQHl4Cd5Wv5bACga8Y', '2021-11-25 14:00:04.517563');

-- --------------------------------------------------------

--
-- Table structure for table `masters_classes`
--

CREATE TABLE `masters_classes` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masters_classes`
--

INSERT INTO `masters_classes` (`id`, `title`, `is_active`, `created_by_id`) VALUES
('1de8b21525a543738b99481bde1b1278', 'Sample Class Name 2', 1, 1),
('77340f85b8684270a0dd547f54f82d81', 'Sample Class Name 1', 1, 1),
('8fda7bd4f9684b40805ae4a0ebf07159', 'Sample Class Name 3', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `masters_config`
--

CREATE TABLE `masters_config` (
  `id` char(32) NOT NULL,
  `contact_number_1` longtext NOT NULL,
  `contact_number_2` longtext NOT NULL,
  `college_name` longtext NOT NULL,
  `college_short_name` varchar(4) NOT NULL,
  `address` longtext NOT NULL,
  `affi_reg_number` longtext NOT NULL,
  `sign_auth` longtext NOT NULL,
  `logo` varchar(100) NOT NULL,
  `background_image` varchar(100) NOT NULL,
  `board_logo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masters_config`
--

INSERT INTO `masters_config` (`id`, `contact_number_1`, `contact_number_2`, `college_name`, `college_short_name`, `address`, `affi_reg_number`, `sign_auth`, `logo`, `background_image`, `board_logo`) VALUES
('e50bc7f4f500486c9bfc300442f1b85e', '98555555', '5545455', 'abc college', 'abc', 'adhhj', '', '', 'uploads/Gautam_Buddha.png', 'uploads/bldmg.jpg', 'uploads/rama_logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `masters_courses`
--

CREATE TABLE `masters_courses` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `duration` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `masters_roles`
--

CREATE TABLE `masters_roles` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masters_roles`
--

INSERT INTO `masters_roles` (`id`, `title`, `is_active`, `created_by_id`) VALUES
('aeebdafa9b4e4ae4ae040f9790210ede', 'Manager Post', 1, 1),
('d72d60eecd604e159a6c76ead8473b10', 'Accountant', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_user`
--

CREATE TABLE `users_user` (
  `user_id` int(11) NOT NULL,
  `uuid` char(32) NOT NULL,
  `password` varchar(1024) NOT NULL,
  `dob` date NOT NULL,
  `title` longtext NOT NULL,
  `email1` longtext NOT NULL,
  `marital_status` longtext NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` longtext NOT NULL,
  `scope` longtext NOT NULL,
  `post` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_user`
--

INSERT INTO `users_user` (`user_id`, `uuid`, `password`, `dob`, `title`, `email1`, `marital_status`, `mobile`, `address`, `scope`, `post`) VALUES
(1, 'd07e0c06095f419e9ee274f74b37959c', '123', '1970-12-01', 'sample', '123@gmail.com', '', '9024343890', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `masters_classes`
--
ALTER TABLE `masters_classes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `masters_classes_created_by_id_9a91a133_fk_users_user_user_id` (`created_by_id`);

--
-- Indexes for table `masters_config`
--
ALTER TABLE `masters_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `masters_courses`
--
ALTER TABLE `masters_courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `masters_courses_created_by_id_c9901862_fk_users_user_user_id` (`created_by_id`);

--
-- Indexes for table `masters_roles`
--
ALTER TABLE `masters_roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `masters_roles_created_by_id_5903cb90_fk_users_user_user_id` (`created_by_id`);

--
-- Indexes for table `users_user`
--
ALTER TABLE `users_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uuid` (`uuid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users_user`
--
ALTER TABLE `users_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `masters_classes`
--
ALTER TABLE `masters_classes`
  ADD CONSTRAINT `masters_classes_created_by_id_9a91a133_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`);

--
-- Constraints for table `masters_courses`
--
ALTER TABLE `masters_courses`
  ADD CONSTRAINT `masters_courses_created_by_id_c9901862_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`);

--
-- Constraints for table `masters_roles`
--
ALTER TABLE `masters_roles`
  ADD CONSTRAINT `masters_roles_created_by_id_5903cb90_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
