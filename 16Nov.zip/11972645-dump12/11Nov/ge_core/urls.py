from django.conf import settings
from django.conf.urls.static import static

from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),

	# API Views.
	path("", views.index, name="main_index"),
	path("api/v1/users/", include("users.urls")),
	path("api/v1/masters", include("masters.urls")),


	# Django Views.
    path("users/", include("users.urls")),
	path("masters/", include("masters.urls")),

	path("fees/", include("fees.urls")),
	#path('api-auth/', include('rest_framework.urls'))
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)