from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response

def login_check(request):
	if request.session.get("username"):
		return HttpResponse("You are logged in")
	else:
		return redirect('login_page') 

def index(request):
	if request.session.get("username"):		
		return render(request, "core/base.html")

		return JsonResponse({"msg" : "Logged In."})
	else:
		#return JsonResponse({"msg" : "Logged Out."})
		return redirect('login_page')