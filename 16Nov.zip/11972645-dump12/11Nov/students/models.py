from django.db import models
import datetime, uuid
from users.models import user
from masters.models import courses, roles, session, religion

# Create your models here.
class student(models.Model):
    uid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    name = models.CharField(max_length=50)
    father_name = models.CharField(max_length=50, blank=True)
    mother_name = models.CharField(max_length=50, blank=True)
    email1 = models.CharField(max_length=50, blank=True)
    email2 = models.CharField(max_length=50, blank=True)
    phone1 = models.CharField(max_length=10)
    phone2 = models.CharField(max_length=10, blank=True)
    genders = [('male', 'male'), ('female','female'), ('other','other')]
    gender = models.CharField(max_length=6, choices=genders, default="male")

    address = models.TextField(blank=True)    
    pin_code = models.CharField(max_length=7, blank=True)
    dob = models.DateField(blank=True)
    admission_date = models.DateField(blank=True)
    aadhar_number =  models.CharField(max_length=12, blank=True)
    photo = models.ImageField(upload_to ='uploads/', blank=True)	
    last_qualification_certificate = models.ImageField(upload_to ='uploads/', blank=True)

    attachment_1 = models.ImageField(upload_to ='uploads/', blank=True)
    attachment_2 = models.ImageField(upload_to ='uploads/', blank=True)
    attachment_3 = models.ImageField(upload_to ='uploads/', blank=True)
    attachment_4 = models.ImageField(upload_to ='uploads/', blank=True)
    attachment_5 = models.ImageField(upload_to ='uploads/', blank=True)    

    course = models.ForeignKey(courses, on_delete=models.CASCADE)
    session = models.ForeignKey(session, on_delete=models.CASCADE)
    religion = models.ForeignKey(religion, on_delete=models.CASCADE, blank=True)

    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)    
    created_on = datetime.datetime.now()

    # dropout / passout / currently studying*
    s_status = [('currently studying','currently studying'), ('passout','passout'), ('dropout', 'dropout')]
    status = models.CharField(max_length=20, choices=s_status, default="currently studying")

    def __str__(self):
        return self.name

