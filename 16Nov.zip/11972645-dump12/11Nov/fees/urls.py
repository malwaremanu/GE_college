from django.contrib import admin
from django.urls import path, include
from . import views


# from vacancy_filling.bankView import getBanksList

urlpatterns = [
    path('', views.index, name="main_fees_index"),    
]
