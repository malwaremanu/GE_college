from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
# Create your views here.
import os 

from .serializers import GetFee_Type
from .models import fee_type
from rest_framework.decorators import api_view
from rest_framework.response import Response

# Create your views here.
@api_view(['GET','POST', 'PUT','DELETE'])
def index(request):
    if request.method == 'GET':
        ft=fee_type.objects.all().order_by('title')
        serializer=GetFee_Type(ft,many=True)
        return Response(serializer.data)
    
    if request.method =='POST':
        print(request.data)
        serializer=GetFee_Type(many=True,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors)
    
    if request.method == 'PUT':
        os.system("clear")
        print(request.data)
        try:            
            r = request.data            
            print("lets try...")
            ft=fee_type.objects.get(title=r["title"])
            ft.title = r["title"]
            ft.amount = r["amount"]
            ft.is_refundable = r["is_refundable"]
            ft.save()
            return Response("all good")
        except:
            return Response("error")

    if request.method == 'DELETE':
        print(request.data)
        try:
            title = request.data[0]["title"]            
            ft=fee_type.objects.get(title=title)
            ft.delete()
            return Response("Deleted Successfully")    
        except:
            return Response('Error in Deletion')