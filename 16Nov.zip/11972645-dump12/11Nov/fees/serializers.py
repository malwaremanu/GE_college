from rest_framework import serializers
from .models import fee_type

class GetFee_Type(serializers.ModelSerializer):
    class Meta:
        model = fee_type
        fields = ('title','is_refundable', 'amount')

        def create(self,validated_data):
            return fee_type.objects.create(**validated_data)