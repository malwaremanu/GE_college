from django.db import models
import uuid, datetime
from users.models import user
# Create your models here.
class fee_type(models.Model):
    #uid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    title = models.CharField(max_length=50)
    #created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = models.CharField(max_length=50, default=datetime.datetime.now())
    # is_refundable = models.BooleanField(default=False)
    #amount = models.IntegerField(default=0)

    def __str__(self):
        return self.title