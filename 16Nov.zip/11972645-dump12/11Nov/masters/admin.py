from django.contrib import admin
from . import models
## Register your models here.

admin.site.register(models.inst_config)
admin.site.register(models.courses)
admin.site.register(models.roles)
admin.site.register(models.session)
admin.site.register(models.religion)
admin.site.register(models.category)
admin.site.register(models.designation)
admin.site.register(models.department)
admin.site.register(models.payment_method)

