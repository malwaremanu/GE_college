from django.db import models
from users.models import user
import uuid, datetime

# Create your models here.
class courses(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    duration = models.TextField(blank=True)    
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.title

class roles(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()

    def __str__(self):
        return self.title
	
    def show_all(self):
        return {
			"id" : self.id,
			"title" : self.title,
			"is_active" : self.is_active,
			"created_by" : self.created_by,
			"created_on" : self.created_on
		}

class session(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()
    start_date = models.DateField()
    end_date = models.DateField()
    
    def __str__(self):
        return self.title

class religion(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()

    def __str__(self):
        return self.title

class inst_config(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, primary_key=True)
    contact_number_1 = models.TextField(blank=True)
    contact_number_2 = models.TextField(blank=True)
    college_name = models.TextField(blank=True)
    college_short_name = models.CharField(max_length=4)
    address = models.TextField(blank=True) 
    website = models.TextField(blank=True) 
    email1 = models.TextField(blank=True) 
    email2 = models.TextField(blank=True) 
    affi_reg_number = models.TextField(blank=True) 
    sign_auth = models.TextField(blank=True) 
    logo = models.ImageField(upload_to ='uploads/', blank=True)	
    background_image = models.ImageField(upload_to ='uploads/')
    board_logo = models.ImageField(upload_to ='uploads/')

    def __str__(self):
        return self.college_name 

class category(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()

    def __str__(self):
        return self.title

class designation(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()

    def __str__(self):
        return self.title

class department(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()

    def __str__(self):
        return self.title

class payment_method(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True,primary_key=True)
    title = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(user, on_delete=models.CASCADE)
    created_on = datetime.datetime.now()

    def __str__(self):
        return self.title

