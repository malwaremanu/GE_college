from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
	# API Views
	path("role", views.roles, name="roles_list"),
	path("session", views.sessions, name="sessions_list"),

	# Django Views
	path("", views.index, name="masters_index"),
	path("roles", views.d_roles, name="d_roles"),
	path("sessions", views.d_sessions, name="d_sessions"),
	
]