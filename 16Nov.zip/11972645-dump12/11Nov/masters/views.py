from django.shortcuts import render
from django.http import JsonResponse

from django.views.decorators.csrf import csrf_exempt 
from . import models

from users.models import user
from django.core import serializers
import json


def index(request):
    return render(request, "masters/base.html")

def d_roles(request):
    return render(request, "masters/roles.html")

def d_sessions(request):
    return render(request, "masters/sessions.html")


# Create your views here.
@csrf_exempt
def sessions(request):
    if request.method == "GET":        
        data = serializers.serialize("json", models.session.objects.all())        
        return JsonResponse(data, safe=False)

    if request.method == "POST":
        data = json.loads(request.body)
        print(request.session["user_id"])

        try:
            db = models.session()        
            db.title = data["title"]
            user_id = user.objects.get(pk = request.session["user_id"]).show_all()["user_id"]
            db.start_date = data["start_date"]
            db.end_date = data["end_date"]
            db.created_by_id = user_id
            db.save()
            return JsonResponse({"msg": "success", "data" : "session created successfully"})
        except:
            return JsonResponse({"msg": "error","data":"User Not Unauthorised."})

    if request.method == "PUT":
        data = json.loads(request.body)
        # print(request.session["user_id"])
        print(data)
        try:
            db = models.session.objects.get(pk=data["sid"])        
            db.title = data["title"]
            user_id = user.objects.get(pk = request.session["user_id"]).show_all()["user_id"]
            db.start_date = data["start_date"]
            db.end_date = data["end_date"]
            db.created_by_id = user_id
            db.save()
            return JsonResponse({"msg": "success", "data" : "session updated successfully"})
        except:
            return JsonResponse({"msg": "error","data":"User Not Unauthorised."})

@csrf_exempt
def roles(request):
    if request.method == "GET":        
        #data = list(models.roles.objects.values())
        data = serializers.serialize("json", models.roles.objects.all())        
        return JsonResponse(data, safe=False)
                
    if request.method == "POST":
        data = json.loads(request.body)
        print(request.session["user_id"])

        # try:
        db = models.roles()        
        db.title = data["title"]
        user_id = user.objects.get(pk = request.session["user_id"]).show_all()["user_id"]
        db.created_by_id = user_id
        db.save()
        return JsonResponse({"msg": "success", "data" : "role created successfully"})
        # except:
        return JsonResponse({"msg": "error","data":"User Not Unauthorised."})

    if request.method == "PUT":
        data = json.loads(request.body)
        try:
            print("going into PUT request.")
            print(user.objects.get(uuid=data["created_by_id"]).show_all())
            user_id = user.objects.get(uuid=data["created_by_id"]).show_all()["user_id"]
            db = models.roles.objects.get(id=data["id"])			
            db.created_by_id = user_id
            db.title = data["title"]
            db.is_active = data["is_active"]
            print(db.show_all())
            print("trying to save it now")
            db.save()
            return JsonResponse({"msg": "success", "data" : "role updated successfully"})
        except:
            return JsonResponse({"msg": "error","data":"couldn't update roles."})

    if request.method == "DELETE":
        data = json.loads(request.body)
        try:
            db=models.roles.objects.get(id=data['id'])
            db.delete()
            msg = "success"			
            data = "Successfully Deleted."
        except:
            msg = "error"			
            data = "Successfully Deleted."

        return JsonResponse({"msg": msg})

    return JsonResponse({"msg": "success", "data": "default get request."})

@csrf_exempt
def session(request):
    context = {
        "msg" : "success"
    }
    return JsonResponse(context)

# @csrf_exempt
# def classes(request):
#     if request.method == "GET":
#         data = list(models.classes.objects.values())
#         return JsonResponse(data, safe=False)

#     if request.method == "POST":
#         data = json.loads(request.body)
#         db = models.classes()        
#         db.title = data["title"]
#         try:
#             user_id = user.objects.get(uuid=data["created_by_id"]).show_all()["user_id"]
#             db.created_by_id = user_id
#             db.save()
#             return JsonResponse({"msg": "success", "data" : "class created successfully"})
#         except:
#             return JsonResponse({"msg": "error","data":"User Not Unauthorised."})
#     if request.method == "PUT":
#         data = json.loads(request.body)
#         try:
#             print("going into PUT request.")
#             print(user.objects.get(uuid=data["created_by_id"]).show_all())
#             user_id = user.objects.get(uuid=data["created_by_id"]).show_all()["user_id"]
#             db = models.classes.objects.get(id=data["id"])			
#             db.created_by_id = user_id
#             db.title = data["title"]
#             db.is_active = data["is_active"]
#             print(db.show_all())
#             print("trying to save it now")
#             db.save()
#             return JsonResponse({"msg": "success", "data" : "class updated successfully"})
#         except:
#             return JsonResponse({"msg": "error","data":"couldn't update class."})

#     if request.method == "DELETE":
#         data = json.loads(request.body)
#         try:
#             db=models.classes.objects.get(id=data['id'])
#             db.delete()
#             msg = "success"			
#             data = "Successfully Deleted."
#         except:
#             msg = "error"			
#             data = "Error in Deleting." 

#         return JsonResponse({"msg": msg, "data" : data})

#     return JsonResponse({"msg": "success", "data": "default get request."})

