from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
	path("", views.list_users, name="list_users"),
	path("login", views.login, name="login_page"),	
	path("logout", views.logout_page, name="logout_page"),
	path("log", views.login_auth, name="login_auth"),
	path("out", views.logout, name="logout_auth"),
]