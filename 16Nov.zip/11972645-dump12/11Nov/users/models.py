from django.db import models
import uuid 

school = "ABCD"
# Create your models here.
class user(models.Model):
    user_id = models.AutoField(primary_key=True)
    username = str(school) + str(user_id)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    password = models.CharField(max_length=1024)
    dob = models.DateField(auto_now=False, auto_now_add=False, default="1970-12-01", blank=True)
    title = models.TextField(blank=True)
    email1 = models.TextField(blank=True)
    marital_status = models.TextField(blank=True)
    mobile = models.CharField(max_length=10)
    address = models.TextField(blank=True)
    scope = models.TextField(blank=True)
    post = models.TextField(blank=True)
    
    def __str__(self):
        return self.title

    def show_all(self):
        j = {
			"user_id" : self.user_id,
            "uuid" : self.uuid,
			"username" : self.username,
			"email1" : self.email1,
			"password" : self.password,
			"title" : self.title
		}

        return j