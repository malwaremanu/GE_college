from django.http.response import HttpResponse, JsonResponse 
from django.shortcuts import render, redirect 
from django.core import serializers

from django.views.decorators.csrf import csrf_exempt 

from . import models

# Create your views here.
def login(request):
	return render(request, "users/login.html")

def logout_page(request):
	try:
		title = request.session["title"]
		context = {
			"msg" : "logged out successfully"
		}			
		del request.session["username"]
		del request.session["title"]
		del request.session["email1"]	
		del request.session["user_id"]	
		
		return render(request, "users/login.html", context)
	except:
		data = "Error Logging out."
		return JsonResponse({
			"msg" : "error",
			"data" : data
		})	 	

@csrf_exempt
def login_auth(request):
	import json
	print(request.body)

	data = json.loads(request.body)
	print(data)

	username = data["username"]
	password = data["password"]
	method = data["method"]
	
	try:
		user_db = models.user.objects.get(email1=str(username)).show_all()

		if (username == user_db["email1"]) and password == user_db["password"]:
			msg = "Authenticated Successfully. Session Cookie Shared."
			request.session["username"] =  user_db["username"]
			request.session["title"] =  user_db["title"] 
			request.session["email1"] =  user_db["email1"] 
			request.session["user_id"] = user_db["user_id"]
		print(user_db)

		if method=="json":
			context = {
				"msg" : "success",
				"data" : msg
			}
			return JsonResponse(context)
		#return redirect('main_index')
		return JsonResponse({ "msg" : msg })
	except:
		msg = "Oops. Either Username or Password is incorrect."

		if method == "json":
			context = {
				"msg" : "error",
				"data" : msg
			}
			return JsonResponse(context)

	context = {
		"msg" : msg
	}

	#return render(request, "users/login.html", context)
	return JsonResponse({ "msg" : msg })

def logout(request):
	try:			
		del request.session["username"]
		del request.session["title"]
		del request.session["email1"]
		msg = "Successfully logged out."
	except:
		msg = "Error Logging out."

	return JsonResponse({"msg": msg})

@csrf_exempt
def test2(request):
	print(request.method)	
	if request.method=="POST":
		context = {
			"msg" : "hitting successfully."
			}
		return JsonResponse(context)

	else:
		return JsonResponse({
			"msg" : "GET Request not allowed."
		})

@csrf_exempt
def list_users(request):
    #db = models.user.objects.all()
    #json_data = serializers.serialize('json', db)
    data = list(models.user.objects.values())
    return JsonResponse(data, safe=False)

