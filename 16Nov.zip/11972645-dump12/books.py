import os, csv
import requests

os.system("clear")

books = open("small_books.csv")

# c = 0
# for book in books:
#     c += 1
#     book.split(",")

c = 0
with books as csvfile:
    r = csv.reader(csvfile)
    
    for row in r:
        c += 1
        if c == 1:
            continue

        b_name = str(row[3]).strip()

        re = requests.get("https://www.googleapis.com/books/v1/volumes?q=" + b_name)

        with open("data/" + "" + b_name + ".json", "w+") as boo:
            boo.write(re.text)
        
        print("saved " + b_name)

        if c == 10:
            break
        

print("------- Program Complete. ----")