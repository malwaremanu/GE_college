/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/ gungunerp_local /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE gungunerp_local;

DROP TABLE IF EXISTS auth_group;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS auth_group_permissions;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS auth_permission;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS auth_user;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS auth_user_groups;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS auth_user_user_permissions;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS django_admin_log;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS django_content_type;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS django_migrations;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS django_session;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS fees_fee_type;
CREATE TABLE `fees_fee_type` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `created_on` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_category;
CREATE TABLE `masters_category` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_category_created_by_id_a73fa8b9_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_category_created_by_id_a73fa8b9_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_courses;
CREATE TABLE `masters_courses` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `duration` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_courses_created_by_id_c9901862_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_courses_created_by_id_c9901862_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_department;
CREATE TABLE `masters_department` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_department_created_by_id_1b0c3b78_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_department_created_by_id_1b0c3b78_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_designation;
CREATE TABLE `masters_designation` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_designation_created_by_id_d9cab428_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_designation_created_by_id_d9cab428_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_inst_config;
CREATE TABLE `masters_inst_config` (
  `id` char(32) NOT NULL,
  `contact_number_1` longtext NOT NULL,
  `contact_number_2` longtext NOT NULL,
  `college_name` longtext NOT NULL,
  `college_short_name` varchar(4) NOT NULL,
  `address` longtext NOT NULL,
  `affi_reg_number` longtext NOT NULL,
  `sign_auth` longtext NOT NULL,
  `logo` varchar(100) NOT NULL,
  `background_image` varchar(100) NOT NULL,
  `board_logo` varchar(100) NOT NULL,
  `email1` longtext NOT NULL DEFAULT (_utf8mb3''),
  `email2` longtext NOT NULL DEFAULT (_utf8mb3''),
  `website` longtext NOT NULL DEFAULT (_utf8mb3''),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_payment_method;
CREATE TABLE `masters_payment_method` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_payment_meth_created_by_id_59216f1b_fk_users_use` (`created_by_id`),
  CONSTRAINT `masters_payment_meth_created_by_id_59216f1b_fk_users_use` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_religion;
CREATE TABLE `masters_religion` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_religion_created_by_id_e6b577bc_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_religion_created_by_id_e6b577bc_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_roles;
CREATE TABLE `masters_roles` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_roles_created_by_id_5903cb90_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_roles_created_by_id_5903cb90_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS masters_session;
CREATE TABLE `masters_session` (
  `id` char(32) NOT NULL,
  `title` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `masters_session_created_by_id_470d27dd_fk_users_user_user_id` (`created_by_id`),
  CONSTRAINT `masters_session_created_by_id_470d27dd_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS students_student;
CREATE TABLE `students_student` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `uid` char(32) NOT NULL,
  `name` varchar(50) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `mother_name` varchar(50) NOT NULL,
  `email1` varchar(50) NOT NULL,
  `email2` varchar(50) NOT NULL,
  `phone1` varchar(10) NOT NULL,
  `phone2` varchar(10) NOT NULL,
  `address` longtext NOT NULL,
  `pin_code` varchar(7) NOT NULL,
  `dob` date NOT NULL,
  `admission_date` date NOT NULL,
  `aadhar_number` varchar(12) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `last_qualification_certificate` varchar(100) NOT NULL,
  `attachment_1` varchar(100) NOT NULL,
  `attachment_2` varchar(100) NOT NULL,
  `attachment_3` varchar(100) NOT NULL,
  `attachment_4` varchar(100) NOT NULL,
  `attachment_5` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `course_id` char(32) NOT NULL,
  `created_by_id` int NOT NULL,
  `religion_id` char(32) NOT NULL,
  `session_id` char(32) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`),
  KEY `students_student_course_id_75708f50_fk_masters_courses_id` (`course_id`),
  KEY `students_student_created_by_id_5fd5c0b3_fk_users_user_user_id` (`created_by_id`),
  KEY `students_student_religion_id_22bd0639_fk_masters_religion_id` (`religion_id`),
  KEY `students_student_session_id_12c782df_fk_masters_session_id` (`session_id`),
  CONSTRAINT `students_student_course_id_75708f50_fk_masters_courses_id` FOREIGN KEY (`course_id`) REFERENCES `masters_courses` (`id`),
  CONSTRAINT `students_student_created_by_id_5fd5c0b3_fk_users_user_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`user_id`),
  CONSTRAINT `students_student_religion_id_22bd0639_fk_masters_religion_id` FOREIGN KEY (`religion_id`) REFERENCES `masters_religion` (`id`),
  CONSTRAINT `students_student_session_id_12c782df_fk_masters_session_id` FOREIGN KEY (`session_id`) REFERENCES `masters_session` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS users_user;
CREATE TABLE `users_user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(32) NOT NULL,
  `password` varchar(1024) NOT NULL,
  `dob` date NOT NULL,
  `title` longtext NOT NULL,
  `email1` longtext NOT NULL,
  `marital_status` longtext NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` longtext NOT NULL,
  `scope` longtext NOT NULL,
  `post` longtext NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;



INSERT INTO auth_permission(id,name,content_type_id,codename) VALUES(1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add user',7,'add_user'),(26,'Can change user',7,'change_user'),(27,'Can delete user',7,'delete_user'),(28,'Can view user',7,'view_user'),(29,'Can add config',8,'add_config'),(30,'Can change config',8,'change_config'),(31,'Can delete config',8,'delete_config'),(32,'Can view config',8,'view_config'),(33,'Can add courses',9,'add_courses'),(34,'Can change courses',9,'change_courses'),(35,'Can delete courses',9,'delete_courses'),(36,'Can view courses',9,'view_courses'),(37,'Can add classes',10,'add_classes'),(38,'Can change classes',10,'change_classes'),(39,'Can delete classes',10,'delete_classes'),(40,'Can view classes',10,'view_classes'),(41,'Can add roles',11,'add_roles'),(42,'Can change roles',11,'change_roles'),(43,'Can delete roles',11,'delete_roles'),(44,'Can view roles',11,'view_roles'),(45,'Can add session',12,'add_session'),(46,'Can change session',12,'change_session'),(47,'Can delete session',12,'delete_session'),(48,'Can view session',12,'view_session'),(49,'Can add religion',13,'add_religion'),(50,'Can change religion',13,'change_religion'),(51,'Can delete religion',13,'delete_religion'),(52,'Can view religion',13,'view_religion'),(53,'Can add inst_config',14,'add_inst_config'),(54,'Can change inst_config',14,'change_inst_config'),(55,'Can delete inst_config',14,'delete_inst_config'),(56,'Can view inst_config',14,'view_inst_config'),(57,'Can add designation',15,'add_designation'),(58,'Can change designation',15,'change_designation'),(59,'Can delete designation',15,'delete_designation'),(60,'Can view designation',15,'view_designation'),(61,'Can add category',16,'add_category'),(62,'Can change category',16,'change_category'),(63,'Can delete category',16,'delete_category'),(64,'Can view category',16,'view_category'),(65,'Can add department',17,'add_department'),(66,'Can change department',17,'change_department'),(67,'Can delete department',17,'delete_department'),(68,'Can view department',17,'view_department'),(69,'Can add payment_method',18,'add_payment_method'),(70,'Can change payment_method',18,'change_payment_method'),(71,'Can delete payment_method',18,'delete_payment_method'),(72,'Can view payment_method',18,'view_payment_method'),(73,'Can add student',19,'add_student'),(74,'Can change student',19,'change_student'),(75,'Can delete student',19,'delete_student'),(76,'Can view student',19,'view_student'),(77,'Can add fee_type',20,'add_fee_type'),(78,'Can change fee_type',20,'change_fee_type'),(79,'Can delete fee_type',20,'delete_fee_type'),(80,'Can view fee_type',20,'view_fee_type');

INSERT INTO auth_user(id,password,last_login,is_superuser,username,first_name,last_name,email,is_staff,is_active,date_joined) VALUES(1,'pbkdf2_sha256$260000$yL6UEpRy5V20mFE0B7ZHnP$2fXu1jBfPRczP5vmgXzN2a8nOQc5JlejyuBnDpEFRMk=','2021-11-14 09:20:45.261009',1,'super','','','super@gmail.com',1,1,'2021-11-09 17:47:29.036070');



INSERT INTO django_admin_log(id,action_time,object_id,object_repr,action_flag,change_message,content_type_id,user_id) VALUES(1,'2021-11-09 17:48:22.623413',X'31','',1,X'5b7b226164646564223a207b7d7d5d',7,1),(2,'2021-11-10 19:22:42.682922',X'65353062633766342d663530302d343836632d396266632d333030343432663162383565','config object (e50bc7f4-f500-486c-9bfc-300442f1b85e)',1,X'5b7b226164646564223a207b7d7d5d',8,1),(3,'2021-11-12 05:20:46.828114',X'65353062633766342d663530302d343836632d396266632d333030343432663162383565','abc college',2,X'5b7b226368616e676564223a207b226669656c6473223a205b224c6f676f222c20224261636b67726f756e6420696d616765222c2022426f617264206c6f676f225d7d7d5d',8,1),(4,'2021-11-12 05:22:37.140332',X'65353062633766342d663530302d343836632d396266632d333030343432663162383565','abc college',2,X'5b7b226368616e676564223a207b226669656c6473223a205b224c6f676f225d7d7d5d',8,1),(5,'2021-11-12 05:22:51.413337',X'65353062633766342d663530302d343836632d396266632d333030343432663162383565','abc college',2,X'5b7b226368616e676564223a207b226669656c6473223a205b224c6f676f222c20224261636b67726f756e6420696d616765222c2022426f617264206c6f676f225d7d7d5d',8,1),(6,'2021-11-14 06:58:46.139706',X'30343734666364362d663464612d343431612d396463352d383965376432396433373632','Manager',1,X'5b7b226164646564223a207b7d7d5d',11,1),(7,'2021-11-14 06:58:50.041630',X'30343734666364362d663464612d343431612d396463352d383965376432396433373632','Manager',2,X'5b5d',11,1),(8,'2021-11-14 06:58:59.779219',X'37343435636632362d383162362d346530362d396661312d373635646439386566613134','Principal',1,X'5b7b226164646564223a207b7d7d5d',11,1),(9,'2021-11-14 08:07:29.800555',X'34653432356562322d633034352d346635362d383834662d643433383232383438353637','Principal',1,X'5b7b226164646564223a207b7d7d5d',11,1),(10,'2021-11-14 08:07:35.798167',X'36636330646633332d373663382d343261322d393234622d323035313465653032323538','Manager',1,X'5b7b226164646564223a207b7d7d5d',11,1),(11,'2021-11-14 08:07:44.057800',X'36303238656335372d306163312d343338332d383635302d333038366463333431613537','Accountant',1,X'5b7b226164646564223a207b7d7d5d',11,1),(12,'2021-11-14 08:08:12.451938',X'65396133613630652d303631612d346335322d386338322d623530336362656434313761','2021-2022',1,X'5b7b226164646564223a207b7d7d5d',12,1),(13,'2021-11-14 08:08:30.904604',X'38643064303437362d393131632d346631632d393263392d323534396564326362366164','2022-2023',1,X'5b7b226164646564223a207b7d7d5d',12,1),(14,'2021-11-14 08:08:40.698518',X'66343062623232662d373834382d343036342d383366342d383862386537303438633438','Hindu',1,X'5b7b226164646564223a207b7d7d5d',13,1),(15,'2021-11-14 08:08:45.967751',X'30313039393335342d326563622d346237622d393835322d623639626534646135393064','Muslim',1,X'5b7b226164646564223a207b7d7d5d',13,1),(16,'2021-11-14 08:08:50.898149',X'63393639613762302d633766662d346337642d386639622d343835636436356537353764','Sikh',1,X'5b7b226164646564223a207b7d7d5d',13,1),(17,'2021-11-14 08:09:11.210149',X'30383432666338382d393730652d346364622d626663622d323537663230373865373639','Christian',1,X'5b7b226164646564223a207b7d7d5d',13,1),(18,'2021-11-14 08:09:22.057227',X'39353233373065322d643138362d346461642d613339322d663230666332396162336334','Parsi',1,X'5b7b226164646564223a207b7d7d5d',13,1),(19,'2021-11-14 08:10:55.347440',X'64323965616565382d373430642d343466302d623639642d396135663832666232616666','Demo College Data',1,X'5b7b226164646564223a207b7d7d5d',14,1),(20,'2021-11-14 08:11:32.241023',X'63336433366165312d633861342d346364662d393562612d633634326266626639366132','BCA',1,X'5b7b226164646564223a207b7d7d5d',9,1),(21,'2021-11-14 08:17:54.168957',X'37633335333236612d626135342d346265382d613364662d303035643861373866326337','PAYTM',1,X'5b7b226164646564223a207b7d7d5d',18,1),(22,'2021-11-14 08:17:59.130135',X'34616631663430382d373761612d346334342d616161652d313762646466353737376432','CASH',1,X'5b7b226164646564223a207b7d7d5d',18,1),(23,'2021-11-14 08:18:05.108727',X'66393861616239332d346263312d346539342d623533652d303962343465653365643434','ONLINE',1,X'5b7b226164646564223a207b7d7d5d',18,1),(24,'2021-11-14 08:18:14.628986',X'35346266333766392d616365332d343133622d386138362d306331626161303765643731','NETBANKING',1,X'5b7b226164646564223a207b7d7d5d',18,1),(25,'2021-11-14 08:18:42.078201',X'37636366396539372d656435362d343065372d613765642d653830363833343039383965','PROFESSOR',1,X'5b7b226164646564223a207b7d7d5d',15,1),(26,'2021-11-14 08:18:48.670063',X'38303062316435342d303132662d346637622d393635302d313637356137343064636630','ACCOUNTANT',1,X'5b7b226164646564223a207b7d7d5d',15,1),(27,'2021-11-14 08:18:54.129452',X'66363333323531392d636464382d346538382d623662332d656230646262643837383637','CLERK',1,X'5b7b226164646564223a207b7d7d5d',15,1),(28,'2021-11-14 08:19:03.228123',X'37376166363636662d353932302d343063362d623763382d333038333635303466396336','HEAD OF DEPARTMENT',1,X'5b7b226164646564223a207b7d7d5d',15,1),(29,'2021-11-14 08:19:17.619864',X'65366438373666382d616161622d346433622d383466632d306231636461643939626462','COMPUTER SCIENCE',1,X'5b7b226164646564223a207b7d7d5d',17,1),(30,'2021-11-14 08:19:29.455283',X'64363532373163362d313333652d346666352d393331302d616564393732393338333436','ELECTRONICS AND COMMUNICATION',1,X'5b7b226164646564223a207b7d7d5d',17,1),(31,'2021-11-14 08:23:54.773507',X'33303839636634632d636336612d343464312d393939612d386537623533346130303435','EDUCATION',1,X'5b7b226164646564223a207b7d7d5d',17,1),(32,'2021-11-14 08:24:03.328011',X'30613665353632322d383966362d343163302d396663372d393833316138613764306237','ARCHITECTURE',1,X'5b7b226164646564223a207b7d7d5d',17,1),(33,'2021-11-14 08:24:12.998958',X'30643366656462622d363630632d346365352d383430372d316336333835623935643834','MEDICAL',1,X'5b7b226164646564223a207b7d7d5d',17,1),(34,'2021-11-14 08:24:42.936137',X'31323038633035362d393333662d346362392d396238662d356536643364393635356230','MECHANICAL',1,X'5b7b226164646564223a207b7d7d5d',17,1),(35,'2021-11-14 08:24:56.089819',X'65353837386165342d313434612d343435312d383965342d363232323232306335643430','IBPS PO CLERK',1,X'5b7b226164646564223a207b7d7d5d',17,1),(36,'2021-11-14 08:25:07.903152',X'64663966666332382d663462372d343564312d623764332d623962393562316666313434','ARTS',1,X'5b7b226164646564223a207b7d7d5d',17,1),(37,'2021-11-14 08:25:25.829594',X'62336463363632312d366465372d343231392d613933352d346131393165613537336566','MCA',1,X'5b7b226164646564223a207b7d7d5d',9,1),(38,'2021-11-14 08:25:35.028441',X'62373932393565322d663365632d343636322d626431322d333634366663643635646161','PGDCA',1,X'5b7b226164646564223a207b7d7d5d',9,1),(39,'2021-11-14 08:25:42.088591',X'36363366646232662d653334322d346332362d396637352d313032653366613736623735','RSCIT',1,X'5b7b226164646564223a207b7d7d5d',9,1),(40,'2021-11-14 09:20:51.655653',X'65343462376364612d353533652d346238382d616563362d616135613862353837346533','GENERAL',1,X'5b7b226164646564223a207b7d7d5d',16,1),(41,'2021-11-14 09:20:59.613647',X'64643965363532332d313935652d343334392d396434302d643866616534653831346531','OBC',1,X'5b7b226164646564223a207b7d7d5d',16,1),(42,'2021-11-14 09:21:10.015641',X'66646431663231632d336363362d346130652d613839662d323562663531333738643939','SC',1,X'5b7b226164646564223a207b7d7d5d',16,1),(43,'2021-11-14 09:21:26.176263',X'31613261376465342d396362302d343464392d386633352d326132626263313238663165','ST',1,X'5b7b226164646564223a207b7d7d5d',16,1),(44,'2021-11-14 09:21:36.295725',X'36666564656632392d303165352d346566382d393265392d323936383739343362383266','EWS',1,X'5b7b226164646564223a207b7d7d5d',16,1),(45,'2021-11-14 09:30:27.038349',X'34666430326535392d346137632d346537362d383631322d376136313763666336393339','CASHFREE',1,X'5b7b226164646564223a207b7d7d5d',18,1),(46,'2021-11-14 09:30:48.450874',X'31','Superuser',2,X'5b7b226368616e676564223a207b226669656c6473223a205b225469746c65225d7d7d5d',7,1),(47,'2021-11-15 15:28:30.621343',X'34','Hostel Security',2,X'5b7b226368616e676564223a207b226669656c6473223a205b22497320726566756e6461626c65225d7d7d5d',20,1),(48,'2021-11-15 15:28:35.895256',X'34','Hostel Security - 5000 * ',2,X'5b7b226368616e676564223a207b226669656c6473223a205b22497320726566756e6461626c65225d7d7d5d',20,1);

INSERT INTO django_content_type(id,app_label,model) VALUES(1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(20,'fees','fee_type'),(16,'masters','category'),(10,'masters','classes'),(8,'masters','config'),(9,'masters','courses'),(17,'masters','department'),(15,'masters','designation'),(14,'masters','inst_config'),(18,'masters','payment_method'),(13,'masters','religion'),(11,'masters','roles'),(12,'masters','session'),(6,'sessions','session'),(19,'students','student'),(7,'users','user');

INSERT INTO django_migrations(id,app,name,applied) VALUES(1,'contenttypes','0001_initial','2021-11-09 17:46:01.354182'),(2,'auth','0001_initial','2021-11-09 17:46:10.157783'),(3,'admin','0001_initial','2021-11-09 17:46:14.707824'),(4,'admin','0002_logentry_remove_auto_add','2021-11-09 17:46:15.321179'),(5,'admin','0003_logentry_add_action_flag_choices','2021-11-09 17:46:15.624600'),(6,'contenttypes','0002_remove_content_type_name','2021-11-09 17:46:16.684361'),(7,'auth','0002_alter_permission_name_max_length','2021-11-09 17:46:17.152349'),(8,'auth','0003_alter_user_email_max_length','2021-11-09 17:46:17.601346'),(9,'auth','0004_alter_user_username_opts','2021-11-09 17:46:17.905842'),(10,'auth','0005_alter_user_last_login_null','2021-11-09 17:46:18.377732'),(11,'auth','0006_require_contenttypes_0002','2021-11-09 17:46:18.663265'),(12,'auth','0007_alter_validators_add_error_messages','2021-11-09 17:46:18.955260'),(13,'auth','0008_alter_user_username_max_length','2021-11-09 17:46:19.407217'),(14,'auth','0009_alter_user_last_name_max_length','2021-11-09 17:46:19.868431'),(15,'auth','0010_alter_group_name_max_length','2021-11-09 17:46:20.325949'),(16,'auth','0011_update_proxy_permissions','2021-11-09 17:46:21.054651'),(17,'auth','0012_alter_user_first_name_max_length','2021-11-09 17:46:21.514725'),(18,'sessions','0001_initial','2021-11-09 17:46:22.836380'),(19,'users','0001_initial','2021-11-09 17:46:26.716092'),(20,'masters','0001_initial','2021-11-09 18:18:06.961874'),(21,'masters','0002_courses_roles_session','2021-11-14 06:57:35.173727'),(22,'masters','0003_religion','2021-11-14 07:43:20.204281'),(23,'masters','0004_auto_20211114_1317','2021-11-14 07:47:09.091545'),(24,'masters','0002_delete_inst_config','2021-11-14 08:05:18.031622'),(25,'masters','0003_auto_20211114_1335','2021-11-14 08:05:58.053932'),(26,'masters','0004_courses_inst_config_religion_roles_session','2021-11-14 08:06:14.228508'),(27,'masters','0005_category_department_designation_payment_method','2021-11-14 08:16:30.467339'),(28,'masters','0006_auto_20211114_1456','2021-11-14 09:26:34.849286'),(29,'students','0001_initial','2021-11-14 10:20:28.748359'),(30,'students','0002_student_gender','2021-11-15 14:27:06.181791'),(31,'fees','0001_initial','2021-11-15 14:29:08.538965'),(32,'fees','0002_fee_type_amount','2021-11-15 14:30:23.277974'),(33,'students','0003_student_status','2021-11-15 16:42:44.080861'),(34,'fees','0003_auto_20211115_2216','2021-11-15 16:46:13.607419'),(35,'students','0004_alter_student_status','2021-11-15 16:46:13.698834'),(36,'fees','0004_fee_type_created_on','2021-11-15 16:49:28.807382');

INSERT INTO django_session(session_key,session_data,expire_date) VALUES('0dnxpmtym5lubcrt68dqbqgcjq2cj2iy',X'2e654a78565430734f7769415176517672686b42704378706a5f4d57645a32686d436c6930744b62516c66487551744b463774374d2d3879384e326c686958323742444f3354704d743461543433534630547a4e6d516a396776452d306d3859344f36525a516c6332304e756b7a584261745838425059512d75637575555931463545494a793451706c6449636f4a59626c4b61794e564d4e4d4251565977773546316257306d3636426c536c53716b31707441634e3449334b6531344f6c393236304d6171635f584137584f444f6d5834784b6e613462375a496f7544746b52774c38534b496a783441616569356269634d39447175544a35777450703161783a316d6c4339673a423461556c5a7873776e34715951536e774778346a512d5a39797a75444b635a5152707a644267394e3959','2021-11-25 15:38:24.791254'),('3aaud0emuy8op4gdrt6ankhxxe2k18rb',X'2e654a77566930454b6743415141502d795a316d776268475246663344636850443155673952583876627a4d443830424a6441664e4242326f61563536632d706749356f4e4f52727943513948336952554a636531346741437373752d486b6e7a39594d41597532385f4974733274465777543079764238313943414f3a316d6c4348343a663076555f5a54795a6f71355f412d5a6861576b37686879546a6531464b3750314379567633475f534f6b','2021-11-25 15:46:02.859255'),('7alqwm8dc6hlfnb51ashp4qpng0ks0vy',X'2e654a77566930454b6743415141502d795a316d776268475246663344636850443155673952583876627a4d443830424a6441664e4242326f61563536632d706749356f4e4f52727943513948336952554a636531346741437373752d486b6e7a39594d41597532385f4974733274465777543079764238313943414f3a316d6b7242733a5747763530424947526659626a59312d5f49303935537149387247677458684d61596679464a6579356e4d','2021-11-24 17:15:16.932535'),('7to4xpa9jfag9j485p9wnlh9yj5noyi5',X'2e654a78566b45304f7769415168655f433268416f6255466a6a46586a7a6a4d304d775573576c6f6a6447573875324336304e334d76486e665f4c784943335073327a6d595a2d73303252424f56723831684f357578697a6f47347a5869586254474a384f615736686978726f5a644a6d4f4379396634416551705f635256657232694a796f59526c7768524b615135517954564b5539714b71526f59697049786870774c4b7974703131304e716c534631426f544e4f4e47384362526d73507874463057306b68396e68366f64575a49757a527a6e4d343533435654644848496a67442d6b5949564d52376377504f686864686663354a4f3867762d2d774c2d5f6742335a4670333a316d6d4270413a68753179473352644466426d526a64615267537146503137667657636a6a4b6c617a312d745a444f364459','2021-11-28 09:29:20.962118'),('7xcyxj060ikd08f3ijiduw06sw7o7s1i',X'2e654a77566930454b6743415141502d795a316d776268475246663344636850443155673952583876627a4d443830424a6441664e4242326f61563536632d706749356f4e4f52727943513948336952554a636531346741437373752d486b6e7a39594d41597532385f4974733274465777543079764238313943414f3a316d6c415a4a3a4b514e49634a32435a54515f6b503041344245776754636879636935786a5744332d5531744e5759546c34','2021-11-25 13:56:45.144070'),('8mgiaufd1j6qyav0dyr57p666nj4eii9',X'2e654a77566930454b6743415141502d795a316d776268475246663344636850443155673952583876627a4d443830424a6441664e4242326f61563536632d706749356f4e4f52727943513948336952554a636531346741437373752d486b6e7a39594d41597532385f4974733274465777543079764238313943414f3a316d6b7250433a324532456c396f5270577a2d7341745756366a796973584961662d45615771356b77786434756f7643326b','2021-11-24 17:29:02.198744'),('c32bfohyab1bsnpcjcpzmhvkiyjhp8c5',X'2e654a78566a45734b776a4155414f2d537459546d355750693072316e434f2d54324b7130304c51723865345336454b334d384f3856635a39475f506579706f6e5552646c314f6d5845664b7a7a463349412d66376f6e6d5a7433556933524e39324b5a766935545839576a5f42694f32735739546965784e63416e396b4a684a42494b4c33677268344178374272514174565938737742516363596d6f6d417463456c526662376d3254676b3a316d6b5644693a41514a686f4b6b5257334d735f77415a76587234314661644f565a46474d6b705378645876377950752d6b','2021-11-23 17:47:42.017832'),('czkr0qhmi9gij088bf1fzjmnhoc5du5b',X'2e654a797256696f747a557852736a4c5555536f745469334b5338784e56624a53636e52796472464a7955724d53385f5853306e537938315053633070316b764c544d314a4b645a7a4c43334a64774d78375a52306c456f7953334a414f6f6f54637775414442326c314e7a457a4278446f4969686b6246444f6f696a6c3579667177517850683573565330413834776d5a673a316d6c736a393a657a66687a484d455750307a6a426d4554367563744c5450534a7a6b654b61707261454367345752625138','2021-11-27 13:05:51.620177'),('gwdvti77gxnirjrwf9q423gebb6fsa48',X'2e654a77566930454b6743415141502d795a316d776268475246663344636850443155673952583876627a4d443830424a6441664e4242326f61563536632d706749356f4e4f52727943513948336952554a636531346741437373752d486b6e7a39594d41597532385f4974733274465777543079764238313943414f3a316d6b5662543a32416a586452474673467574304a726b6c554e334c48306e6947755f6e77684c54324d335a3443674f4334','2021-11-23 18:12:15.104571'),('ix5buzbzk1u4gvg81qzdu7xcpo1i8q0o',X'2e654a77566a4d454f514441515250396c7a374a4a75596d49496e3544796936706446573054754c6674626333387a4c7a77685034506f3077314b443759577a6f4d4f66756b525955542d7743627059644264525039465047466771494e7271384345617542415777474f7455616c525a6458734f7548704a49745f506c71425733775f4e344350553a316d6c7445473a38486d476d3232544437733641474c52684546704566664a5f304e6575726e6961664b7a4d707151664273','2021-11-27 13:38:00.167042'),('kp5srvlv5a35f9aqb43okh2iqg38djwy',X'2e654a7856546b7471777a4151766375736a5a417332314a434b5530617375735a7a49772d7356724c4b70473843726c374c544346374e366639344131755f7543306345525475665079357639787557576d4355576b33567a5a6a363432575a32576b75365676674f445a525135747249474838333049434c474761784b614b564837644b6d456c784d2d72384743776352514d6a726d55615f785551384b49526d682d335647505f594e4a53376f46596a6244647a657972336a7276325a654243664f307456737a364d455443616d6c35394b31576c7542324b73444b6466356e7573424f636d4f63303543534b39363551396d514e3370566c6c4c38507744342d6c6164773a316d6d4267723a5033635268435f6a364f794139734c332d57767a6669774d376653646961426c773956655846326c334341','2021-11-28 09:20:45.296307'),('rvtsmehli0vfvlcsul3apvmu39idcb0d',X'2e654a77566930454b6743415141502d795a316d776268475246663344636850443155673952583876627a4d443830424a6441664e4242326f61563536632d706749356f4e4f52727943513948336952554a636531346741437373752d486b6e7a39594d41597532385f4974733274465777543079764238313943414f3a316d6b7250453a484e71616a555162724b4e6864723457466657584c324a526a30534a5750777a6a38643643494e634f5a45','2021-11-24 17:29:04.147863'),('utq6c63paim932v5o6ch082je8o2wzaw',X'2e654a78566a73304f77694151684e2d4673794651326f4c47474b76476d385f5137504a6a30564b4d304a50783353314a4c3935323535765a32512d5a6b33315045437a5a6b65353076757a4e41365a3770415a70694d614f6954707652354e6f4e2d64344c654f4262456a326553794a424f473144427469415f69524c777176785046654671706a574541506378373655744a37555f695f687143666469706737645678796d2d5074466a6f53684f396c56644f715f667677414270574e4b56626c5872454c6c51776a46684b36554d42326a6b4671577458634e55437778467a5268447a6f57546a58526233594b715653574e51664c39416370555672453a316d6d3931633a4d34515f4b6c6272474f6f6357552d4347734f36304c6b5967783938383839654a39686b5830667552396f','2021-11-28 06:30:00.807675'),('xxz6fi6z1p0hwej6tch067yc6qehidef',X'2e654a77566930454b6743415141502d795a316d776268475246663344636850443155673952583876627a4d443830424a6441664e4242326f61563536632d706749356f4e4f52727943513948336952554a636531346741437373752d486b6e7a39594d41597532385f4974733274465777543079764238313943414f3a316d6c4163573a70654d6c2d7375616c424242755646714261533259642d6d6b4951486c3443643557763562414367613859','2021-11-25 14:00:04.517563');

INSERT INTO fees_fee_type(id,title,created_on) VALUES(1,'Registration Fees','2021-11-15 22:19:25.910997'),(2,'Sports and Cultral Fees','2021-11-15 22:19:25.910997'),(3,'Hostel Fees','2021-11-15 22:19:25.910997'),(4,'Hostel Security','2021-11-15 22:19:25.910997'),(6,'AC Hostel Fees','2021-11-15 22:19:25.910997');

INSERT INTO masters_category(id,title,is_active,created_by_id) VALUES('1a2a7de49cb044d98f352a2bbc128f1e',X'5354',1,1),('6fedef2901e54ef892e929687943b82f',X'455753',1,1),('dd9e6523195e43499d40d8fae4e814e1',X'4f4243',1,1),('e44b7cda553e4b88aec6aa5a8b5874e3',X'47454e4552414c',1,1),('fdd1f21c3cc64a0ea89f25bf51378d99',X'5343',1,1);

INSERT INTO masters_courses(id,title,duration,is_active,created_by_id) VALUES('663fdb2fe3424c269f75102e3fa76b75',X'5253434954',X'33',1,1),('b3dc66216de74219a9354a191ea573ef',X'4d4341',X'3234',1,1),('b79295e2f3ec4662bd123646fcd65daa',X'5047444341',X'3132',1,1),('c3d36ae1c8a44cdf95bac642bfbf96a2',X'424341',X'3336',1,1);

INSERT INTO masters_department(id,title,is_active,created_by_id) VALUES('0a6e562289f641c09fc79831a8a7d0b7',X'415243484954454354555245',1,1),('0d3fedbb660c4ce584071c6385b95d84',X'4d45444943414c',1,1),('1208c056933f4cb99b8f5e6d3d9655b0',X'4d454348414e4943414c',1,1),('3089cf4ccc6a44d1999a8e7b534a0045',X'454455434154494f4e',1,1),('d65271c6133e4ff59310aed972938346',X'454c454354524f4e49435320414e4420434f4d4d554e49434154494f4e',1,1),('df9ffc28f4b745d1b7d3b9b95b1ff144',X'41525453',1,1),('e5878ae4144a445189e46222220c5d40',X'4942505320504f20434c45524b',1,1),('e6d876f8aaab4d3b84fc0b1cdad99bdb',X'434f4d505554455220534349454e4345',1,1);

INSERT INTO masters_designation(id,title,is_active,created_by_id) VALUES('77af666f592040c6b7c830836504f9c6',X'48454144204f46204445504152544d454e54',1,1),('7ccf9e97ed5640e7a7ede8068340989e',X'50524f464553534f52',1,1),('800b1d54012f4f7b96501675a740dcf0',X'4143434f554e54414e54',1,1),('f6332519cdd84e88b6b3eb0dbbd87867',X'434c45524b',1,1);

INSERT INTO masters_inst_config(id,contact_number_1,contact_number_2,college_name,college_short_name,address,affi_reg_number,sign_auth,logo,background_image,board_logo,email1,email2,website) VALUES('d29eaee8740d44f0b69d9a5f82fb2aff',X'39303234333433383930',X'',X'44656d6f20436f6c6c6567652044617461','DEDM',X'4a6169707572',X'31323331323341462d43425345',X'52616d7072616b617368205961646176','uploads/logo.png','uploads/logo_LBy1bs1.png','uploads/logo_oDtgJ7e.png',X'',X'',X'');

INSERT INTO masters_payment_method(id,title,is_active,created_by_id) VALUES('4af1f40877aa4c44aaae17bddf5777d2',X'43415348',1,1),('4fd02e594a7c4e7686127a617cfc6939',X'4341534846524545',1,1),('54bf37f9ace3413b8a860c1baa07ed71',X'4e455442414e4b494e47',1,1),('7c35326aba544be8a3df005d8a78f2c7',X'504159544d',1,1),('f98aab934bc14e94b53e09b44ee3ed44',X'4f4e4c494e45',1,1);

INSERT INTO masters_religion(id,title,is_active,created_by_id) VALUES('010993542ecb4b7b9852b69be4da590d',X'4d75736c696d',1,1),('0842fc88970e4cdbbfcb257f2078e769',X'43687269737469616e',1,1),('952370e2d1864dada392f20fc29ab3c4',X'5061727369',1,1),('c969a7b0c7ff4c7d8f9b485cd65e757d',X'53696b68',1,1),('f40bb22f7848406483f488b8e7048c48',X'48696e6475',1,1);

INSERT INTO masters_roles(id,title,is_active,created_by_id) VALUES('4e425eb2c0454f56884fd43822848567',X'5072696e636970616c',1,1),('6028ec570ac1438386503086dc341a57',X'4163636f756e74616e74',1,1),('6cc0df3376c842a2924b20514ee02258',X'4d616e61676572',1,1);

INSERT INTO masters_session(id,title,is_active,start_date,end_date,created_by_id) VALUES('8d0d0476911c4f1c92c92549ed2cb6ad',X'323032322d32303233',1,'2022-04-01','2023-03-31',1),('e9a3a60e061a4c528c82b503cbed417a',X'323032312d32303232',1,'2021-04-01','2022-03-31',1);

INSERT INTO users_user(user_id,uuid,password,dob,title,email1,marital_status,mobile,address,scope,post) VALUES(1,'d07e0c06095f419e9ee274f74b37959c','123','1970-12-01',X'537570657275736572',X'31323340676d61696c2e636f6d',X'','9024343890',X'',X'',X'');